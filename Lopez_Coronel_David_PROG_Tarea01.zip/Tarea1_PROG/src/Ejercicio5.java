/**
 * @author David López Coronel
 */

/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 5: casa a pintar.

Necesitamos calcular los metros cuadrados que tiene la superficie exterior de la casa.
La casa está formada por dos paneles cuadrados (A), dos paneles rectangulares (B), dos paneles triangulares (C) y dos techos rectangulares (D).

Escribe un programa en Java que solicite:

    el número de metros del lado largo de la figura,
    el número de metros del lado corto de la figura.

Y a continuación calcule y muestre por pantalla los metros cuadrados que tiene la superficie exterior de la casa.
*/

public class Ejercicio5 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int ladoLargo ;
        int ladoCorto ;
                
        // Variables de salida
        double superficieTipoA ; //Lado corto.
        double superficieTipoB ; //Lado largo.
        double superficieTipoC ; //Lado corto.
        double superficieTipoD ; //Lado largo.
        double superficieTotal ; //Suma todos los lados.

        // Variables auxiliares
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
       
        System.out.println("Ejercicio 5.\nMETROS CUADRADOS DEL EXTERIOR DE UNA CASA");
        System.out.println("----------------------");
        
        System.out.print("Introduzca la longitud del lado largo de la figura (en metros): ");
        ladoLargo = teclado.nextInt();
        System.out.print("Introduzca la longitud del lado corto de la figura (en metros): ");
        ladoCorto = teclado.nextInt();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //Calculo metros cuadrados = (lado * lado);
        superficieTipoA = ladoCorto * ladoCorto ; //Como vemos en la figura A es un cuadrado y es lado corto por corto.
        superficieTipoB = ladoCorto * ladoLargo ;
        //Calculo C (triangulo equilatero) = (raiz3 / 4) * (c*c) 
        superficieTipoC =  (1.732050807568877 / 4) * (ladoCorto * ladoCorto) ;
        superficieTipoD = ladoCorto * ladoLargo ;
        // Calculo Superficie total = suma de todos sus lados (TipoA + TipoB + TipoC + TipoD) * 2
        superficieTotal = (superficieTipoA + superficieTipoB + superficieTipoC + superficieTipoD) * 2 ;
                
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
                
        System.out.print ("Metros cuadrados de los paneles de tipo A: " );
        System.out.println (superficieTipoA);
        System.out.print ("Metros cuadrados de los paneles de tipo B: " );
        System.out.println (superficieTipoB);
        System.out.print ("Metros cuadrados de los paneles de tipo C: " );
        System.out.println (superficieTipoC);
        System.out.print ("Metros cuadrados de los paneles de tipo D: " );
        System.out.println (superficieTipoD);
        System.out.println ();
        System.out.println ("Superficie total del exterior de la casa: " + superficieTotal + " metros cuadrados totales" );
       
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");        
        
    }

