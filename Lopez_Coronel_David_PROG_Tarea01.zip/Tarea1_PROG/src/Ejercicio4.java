/**
 * @author David López Coronel
 */

/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 4: bombillas y estanterías.

En una ferretería se quiere colocar un número x de bombillas en estanterías. En cada estantería caben cuarenta bombillas.

Escribe un programa en Java que pida el número de bombillas a colocar y calcule cuántas estanterías completas se necesitan, 
así como cuántos huecos libres quedarían en la última estantería no completa.
*/

public class Ejercicio4 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int xBombillas ;
        
        // Variables de salida
        int estanteriasCompletas ;
        int estanteriaIncompleta ;

        // Variables auxiliares
        int estanterias = 40;
        

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
       
        System.out.println("Ejercicio 4.\nESTANTERÍAS Y BOMBILLAS");
        System.out.println("----------------------");
        
        System.out.print("Introduzca la cantidad de bombillas que se desean colocar: ");
        xBombillas = teclado.nextInt();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Estanterias comopletas, dividire el numero de bombillas a colocar(xBombillas entre 40 bombillas que caben en una estanteria y me dara el resultado redondeado al ser un numero entero "int"
        estanteriasCompletas = xBombillas / 40 ;
        // Estanteria incompleta, cojo la variable "estanterias" que tiene definido el valor de 40 huecos, y le voy a restar el resto de bombillas a colocar(xBombillas) dandome asi los huecos libres.
        estanteriaIncompleta = estanterias - (xBombillas % 40) ;
                
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
                
        System.out.print ("Cantidad de estanterías completas requeridas: " + estanteriasCompletas);
        System.out.println ();
        System.out.print ("Cantidad de huecos libres en las últimas estanterias no completa: " + estanteriaIncompleta);
        System.out.println ();
       
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");        
        
    }
