package maquina;

import java.util.Arrays;

/**
 * Clase Batidora, que representa una batidora como tipo de máquina eléctrica
 * enchufable (pero no recargable).
 *
 * Los objetos de esta clase modifican y detallan ciertos aspectos del
 * funcionamiento de una máquina eléctrica genérica, pero no contienen ningún
 * atributo adicional.
 *
 * @author David López Coronel
 */
public final class Batidora extends MaquinaElectrica implements Enchufable {

    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    // Atributos estáticos constantes públicos
    // (rangos y requisitos de los atributos de objeto)
    // Son públicos, disponibles para que cualquier código cliente pueda acceder a ellos
    // ---------------------------------------------------------------------------------
    /**
     * Establece un valor para el voltaje por defecto de una Batidora. Valor:
     * {@value DEFAULT_VOLTAJE_BATIDORA} voltios (v.)
     */
    public static final int DEFAULT_VOLTAJE_BATIDORA = 230;
    /**
     * Establece un valor para la potencia por defecto de una Batidora. Valor:
     * {@value DEFAULT_POTENCIA_BATIDORA} watios.
     */
    public static final int DEFAULT_POTENCIA_BATIDORA = 700;

    /**
     * Array que en cada fila establece los países que comparten un determinado
     * voltaje estándar. Cada fila por tanto, corresponderá a un voltaje
     * estándar diferente. Este listado se usa internamente por la clase, por lo
     * que no es necesario que sea público.
     *
     */
    private final static String[][] LISTA_PAISES_COMPATIBLES = {
        {"Japón", "Corea"}, //para 110 v.
        {"USA"}, //para 120 v.
        {"China"},//para 220 v.
        {"España", "Alemania", "Francia", "Bélgica"}//para 230 v.
    };

    String listaPaises = "";

    // ------------------------------------------------------------
    //                        CONSTRUCTOR
    // ------------------------------------------------------------
    /**
     * Crea un nuevo objeto de tipo Batidora, con los valores indicados como
     * parámetros para marca y modelo, con un voltaje estándar de
     * {@value DEFAULT_VOLTAJE_BATIDORA} V. y una potencia estándar de
     * {@value DEFAULT_POTENCIA_BATIDORA} W.
     *
     * @param marca - La marca de la Batidora.
     * @param modelo - El modelo de Batidora.
     * @param voltaje - El voltaje a asignar a la Batidora. (Valores válidos:
     * Japón/Corea: 110v.; USA: 120v.; China: 220v.;
     * España/Alemania/Francia/Bélgica: 230v.)
     * @param potenciaElectrica - . La potencia eléctrica a asignar a la
     * Batidora.(Valores válidos: 500/600/700/800/1000/1200/1500 w.)
     *
     * @throws IllegalArgumentException - Cuando se intenta asignar un voltaje o
     * una potencia no válidos para una Batidora.
     */
    public Batidora(String marca, String modelo, int voltaje, double potenciaElectrica) throws IllegalArgumentException {
        super(marca, modelo, voltaje, potenciaElectrica);        
        
        //Si la 'potenciaElectrica' es distinta
        if (potenciaElectrica != 500 && potenciaElectrica != 600 && potenciaElectrica != 700 && potenciaElectrica != 800 && potenciaElectrica != 1000 && potenciaElectrica != 1200 && potenciaElectrica != 1500) {
            // No se crea un objeto.
            // Se lanza una excepción
            // Si no se crea, no se deberia incrementar   
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error en potencia eléctrica: %.2f. (Valores válidos: 500/600/700/800/1000/1200/1500 W).",
                    potenciaElectrica));
        }        
        switch (voltaje) {
            case 110:
                listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[0]);
                break;
            case 120:
                listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[1]);
                break;
            case 220:
                listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[2]);
                break;
            case 230:
                listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[3]);
                break;
            default:
                //Si el "voltaje" es distinto al indicado según los paises
                // Se lanza una excepción               
                Maquina.proximoNumSerie--;
                Maquina.cantidadMaquinasFabricadas--;
                throw new IllegalArgumentException(String.format("Error en voltaje: %d (Valores válidos: Japón/Corea: 110v.; USA: 120v.; China: 220v.; "
                        + "España/Alemania/Francia/Bélgica: 230v.).", voltaje));
        } 
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaz Enchufable        
    // ------------------------------------------------------------
    @Override
    /**
     * Método para consultar el valor del voltaje de una
     * <strong>batidora</strong>.
     *
     * @return El voltaje de la batidora.
     */
    public int getVoltaje() {
        return this.voltaje;
    }

    /**
     * Método para obtener un array de Strings con el listado de países para los
     * que el voltaje es compatible con la batidora.
     *
     * @return Devuelve un array de Strings con los nombres de los países
     * compatibles según el voltaje de la batidora.
     */
    @Override
    public String[] getPaisesCompatibles() {
        String[] String = null;

        switch (this.getVoltaje()) {
            case 110: // Japón, Corea
                String = LISTA_PAISES_COMPATIBLES[0];
                break;
            case 120: // USA
                String = LISTA_PAISES_COMPATIBLES[1];
                break;
            case 220: // China
                String = LISTA_PAISES_COMPATIBLES[2];
                break;
            case 230: // España, Alemania, Francia, Bélgica
                String = LISTA_PAISES_COMPATIBLES[3];
                break;
        }

        return String;
    }

    // --------------------------------
    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    /**
     * Método que permite obtener la representación como String de una Batidora,
     * con el formato: { Marca: XXX; modelo: YYY; NS: ZZZ; Voltaje: WWW v.;
     * Potencia: VVVV W.; Países Compatibles: WWW} donde XXX representa la
     * marca, YYY representa el modelo, ZZZ representa el número de serie, WWW
     * representa el voltaje, VVV representa la potencia eléctrica y RRR
     * representa la lista de países compatibles con el voltaje de esta batidora
     *
     * @return La representación como String de una Batidora.
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Países compatibles: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                listaPaises);
    }
}
