package tarea2;

/**
 * Ejercicio 1: uso del depurador.
 *
 * En este ejercicio no se pide que elabores código en Java, tampoco está
 * permitido modificar el código del ejercicio, sino que debes grabar un pequeño
 * video donde realices lo que se comenta más abajo, o bien elaborar un
 * documento donde aparezca lo siguiente:
 * <ul>
 * <li>Breve descripción de lo que realiza el programa.</li>
 * <li>Debido a un error en el programa (es un problema de diseño del programa),
 * jamás llega a mostrar el texto: "Estamos en el 8" por consola. A través del
 * depurador debes conseguir que se muestre, sin modificar el código.</li>
 * <li>Tal y como se ve en la imagen de más abajo, debes poner las líneas de
 * comentarios: // Mi práctica: xxxxxxxxxxxxxx - F4 en esta // línea de F4 para
 * que se ejecute automáticamente hasta aquí donde xxxxxxxxxxxxxx será tu nombre
 * y apellidos
 * <li>Para ello, puedes hacer situarte en la línea que ves en la imagen y
 * pulsar F4, de modo que el programa se ejecute automáticamente hasta
 * detenerse.</li>
 * <li>Ahora en tiempo de ejecución puedes cambiar el valor de la variable total
 * en la ventana del depurador llamada "Variables". No olvides realizar una
 * captura de pantalla con la variable modificada para adjuntarla al documento
 * (si optas por elaborar el documento). Es importante modificar la variable en
 * el lugar adecuado, dado que si no, no funcionaría. Después explica en que
 * consistía el fallo con tus propias palabras.</li>
 * <li>Sigue con la ejecución del programa paso a paso, pulsando F8, hasta que
 * finalice el programa. No olvides realizar la captura de pantalla donde se
 * muestre la consola con el resultado final.</li>
 * </ul>
 *
 * Recuerda, en ningún caso debe modificarse el código, solo se debe usar el
 * depurador..
 *
 * @author David Lopez Coronel.
 */
public class Ejercicio01 { 
    // Enlace para ver este ejercicio: https://youtu.be/KLSoN2RN6Ug
    public static void main(String[] args) {

        int contador;
        int total = 0;

        for (contador = 0; contador < 10; contador++) {

            total = total + contador;
            
            // Mi práctica: David López Coronel -F4 en esta
            // línea de F4 para que se ejecute automáticamente hasta aqui
            System.out.println("total: " + total);

            if (total < 8) {
                System.out.println("Estamos en el rango de [0 a 8)");
            } else if (total == 8) {
                System.out.println("Estamos en el 8");

            } else {
                System.out.println("Estamos en el rango de 9 o mayor");
            }
        }
    }
}
