package maquina;

import java.util.Arrays;

/**
 * <p>
 * Clase que modela un tipo especial de coche: un coche eléctrico. Con capacidad
 * de ser enchufado, con una batería recargable, y con capacidad para
 * desplazarse. Añade a la clase Coche de la que hereda, los atributos
 * siguientes:</p>
 *
 * <ul>
 * <li>Voltaje de la batería. Valores válidos serán: 12V en España y Portugal,
 * 24V en Francia y Bélgica y 48V en Inglaterra.</li>
 * <li>Capacidad máxima de la batería. Valores válidos (en kWh) serán: 35, 50,
 * 75, 100, 125, 150, 200. </li>
 * <li>Carga efectiva. La cantidad de carga que se estima que queda en el Coche
 * eléctrico. En futuras versiones, la carga efectiva se calculará en función de
 * los km recorridos y de la autonomía del vehículo. </li>
 * </ul>
 *
 * @author David López Coronel
 */
public final class CocheElectrico extends Coche implements Desplazable, Enchufable, Recargable {

    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    // Atributos estáticos constantes públicos
    // (rangos y requisitos de los atributos de objeto)
    // Son públicos, disponibles para que cualquier código cliente pueda acceder a ellos
    // ---------------------------------------------------------------------------------
    /**
     * Capacidad máxima por defecto de la batería de un Coche Eléctrico:
     * {@value DEFAULT_CAPACIDAD_MAXIMA_BATERIA} KiloWatios-Hora.(kWh)
     */
    public static final double DEFAULT_CAPACIDAD_MAXIMA_BATERIA = 100;
    /**
     * Potencia por defecto de un Coche Eléctrico: {@value DEFAULT_POTENCIA}
     * Watios.
     */
    public static final double DEFAULT_POTENCIA = 100000;
    /**
     * Carga efectiva por defecto para un Coche Eléctrico. Se entiende que la
     * carga efectiva va a ser siempre la mitad de la capacidad máxima de la
     * batería, por lo que los coches saldrán de fábrica siempre con la batería
     * a media carga. Valor: {@value DEFAULT_CARGA_EFECTIVA}
     * KiloWatios-Hora.(kWh)
     */
    public static final double DEFAULT_CARGA_EFECTIVA = DEFAULT_CAPACIDAD_MAXIMA_BATERIA / 2;
    /**
     * La autonomía mínima permitida que se podrá asignar a un Coche Eléctrico.
     * Valor: {@value MIN_AUTONOMIA} kilómetros (km).
     */
    public static final double MIN_AUTONOMIA = 300;
    /**
     * La autonomía máxima permitida que se podrá asignar a un Coche Eléctrico.
     * Valor: {@value MAX_AUTONOMIA} kilómetros (km).
     */
    public static final double MAX_AUTONOMIA = 600;
    /**
     * Array que en cada fila establece los países que comparten un determinado
     * voltaje estándar. Cada fila por tanto, corresponderá a un voltaje
     * estándar diferente. Este listado se usa internamente por la clase, por lo
     * que no es necesario que sea público.
     *
     */
    private final static String[][] LISTA_PAISES_COMPATIBLES = {
        {"España", "Portugal"}, // 12 v.
        {"Francia", "Bélgica"}, // 24 v.
        {"Inglaterra"} // 48 v.
    };
    String listaPaises = "";

    // ------------------------------------------------------------
    //               ATRIBUTOS DE OBJETO (todos privados)
    // ------------------------------------------------------------  
    private int voltajeBateria;
    private double capacidadMaximaBateria;
    private double cargaEfectiva;
    private double autonomia;

    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
    /**
     * Constructor público de la clase CocheElectrico.Crea un nuevo Coche
     * Eléctrico a partir de los datos recibidos como parámetros (marca, modelo,
     * fuerza Motriz, voltaje de la batería y capacidad máxima de la batería).
     * Como capacidad efectiva de carga, a la salida de fábrica, la batería
     * siempre irá a media carga respecto a su capacidad máxima
     *
     * @param marca - La marca del Coche.
     * @param modelo - El modelo del Coche.
     * @param fuerzaMotriz - Fuerza motriz del coche.
     *
     * @throws IllegalArgumentException - Cuando se intenta asignar como fuerza
     * motriz un valor no válido para un Coche.
     */
    public CocheElectrico(String marca, String modelo, Fuerza fuerzaMotriz) throws IllegalArgumentException {
        super(marca, modelo, fuerzaMotriz);
        if (fuerzaMotriz == null || fuerzaMotriz != Fuerza.ELECTRICIDAD) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error en fuerza Motriz: %s. Para un coche eléctrico debe ser necesariamente %s.",
                    fuerzaMotriz, Fuerza.ELECTRICIDAD));
        } else {
            this.capacidadMaximaBateria = CocheElectrico.DEFAULT_CAPACIDAD_MAXIMA_BATERIA;
            //Según el JavaDoc, voltaje por defecto.
            this.voltajeBateria = 12;
            this.autonomia = CocheElectrico.MIN_AUTONOMIA;            
        }
    }

    /**
     * Constructor público de la clase CocheElectrico.Crea un nuevo Coche
     * Eléctrico a partir de los datos recibidos como parámetros (marca, modelo,
     * fuerza Motriz, voltaje de la batería y capacidad máxima de la
     * batería).Como capacidad efectiva de carga, a la salida de fábrica, la
     * batería siempre irá a media carga respecto a su capacidad máxima
     *
     * @param marca - La marca del Coche.
     * @param modelo - El modelo del Coche.
     * @param fuerzaMotriz - Fuerza motriz del coche.
     * @param voltajeBateria - El voltaje de la batería del Coche Eléctrico
     * @param capacidadMaximaBateria - La capacidad máxima de la batería del
     * Coche Eléctrico.
     * @param autonomia - La autonomía de este coche eléctrico. (Km que se
     * pueden recorrer sin repostar con una carga máxima de su batería)
     *
     * @throws NullPointerException - Cuando el atributo fuerza motriz es null
     * @throws IllegalArgumentException - Cuando se intenta asignar un valor no
     * permitido como voltaje de la batería o como capacidad máxima o como
     * autonomía.
     */
    public CocheElectrico(String marca, String modelo, Fuerza fuerzaMotriz, int voltajeBateria, double capacidadMaximaBateria, double autonomia)
            throws IllegalArgumentException {
        this(marca, modelo, fuerzaMotriz);                

        if (voltajeBateria != 12 && voltajeBateria != 24 && voltajeBateria != 48) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error voltaje: %d. v. Valores válidos=> 12 v. en España y Portugal, 24 v. en Francia y Bélgica  y 48 v. en Inglaterra.", voltajeBateria));
        } else if (capacidadMaximaBateria != 35 && capacidadMaximaBateria != 50 && capacidadMaximaBateria != 75 && capacidadMaximaBateria != 100
                && capacidadMaximaBateria != 125 && capacidadMaximaBateria != 150 && capacidadMaximaBateria != 200) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error capacidad batería: %.2fw. No valida. Valores válidos=> 35.00w, 50.00w, 75.00w, 100w, 125w, 150w y 200w.", capacidadMaximaBateria));
        } else if (autonomia < CocheElectrico.MIN_AUTONOMIA || autonomia > CocheElectrico.MAX_AUTONOMIA) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error Autonomia: %.1f.No valida. Autonomía valida => %f y %f", autonomia, CocheElectrico.MIN_AUTONOMIA, CocheElectrico.MAX_AUTONOMIA));

        } else {           
            this.voltajeBateria = voltajeBateria;
            this.capacidadMaximaBateria = capacidadMaximaBateria;
            this.autonomia = autonomia;
            this.cargaEfectiva = this.capacidadMaximaBateria / 2;
            switch (voltajeBateria) {
                case 12:
                    listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[0]);
                    break;
                case 24:
                    listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[1]);
                    break;
                case 48:
                    listaPaises = Arrays.toString(LISTA_PAISES_COMPATIBLES[2]);
                    break;
            }
        }        
    }

    // ------------------------------------------------------------
    //            Método abstracto 'TipoCombustible'
    // ------------------------------------------------------------
    /**
     * Método de consulta que permite obtener el tipo de combustible usado por
     * un Coche Eléctrico.
     *
     * @return El tipo de combustible usado.
     */
    @Override
    public TipoCombustible getTipoCombustible() {
        //solo puede ser Electricidad para cochesEléctricos
        return TipoCombustible.ELECTRICIDAD;
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaze Desplazable
    // ------------------------------------------------------------
    /**
     * Método que comprueba en primer lugar si la carga efectiva de la batería
     * permitiría un desplazamiento de la cantidad de kilómetros indicados como
     * parámetro. Si hay batería suficiente, desplaza el coche esos kilómetros,
     * actualizando el total de kilómetros recorridos, los kilómetros recorridos
     * sin repostar, y la carga efectiva restante en la batería
     *
     * @param kilometros - Los kilómetros que se quiere desplazar el coche.
     */
    @Override
    public void desplazar​(double kilometros) {
        // Porcentaje equivalente entre los kilometros y la capacidad máxima.
        double porcentaje = this.autonomia / this.capacidadMaximaBateria;
        if ((this.cargaEfectiva * porcentaje) > kilometros) {
            this.kilometrosSinRepostar += kilometros;
            this.kilometrosTotalesRecorridos += kilometros;
            // Carga efectiva restante
            this.cargaEfectiva = this.cargaEfectiva - (kilometros / porcentaje);
        } else {
            throw new IllegalArgumentException(String.format("Error: Porcentaje de carga: %.2f. No es suficiente para recorrer %.1f kilómetros.",
                    this.cargaEfectiva, kilometros));
        }
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaze Recargable
    // ------------------------------------------------------------
    /**
     * Método que permite cargar la batería de un Coche Eléctrico, estableciendo
     * su carga efectiva al valor de la capacidad máxima de su batería. Tras
     * cargar la batería, los kilómetros sin repostar se inicializan a 0.
     *
     */
    @Override
    public void cargar() {
        // Para poner los kilometros sin repostar a 0
        // Reutilizo el método 'repostar()'
        CocheElectrico.super.repostar();
        this.cargaEfectiva = this.capacidadMaximaBateria;
    }

    /**
     * Método que calcula y devuelve la carga de batería que quedaría disponible
     * tras realizar un desplazamiento de la cantidad de kilómetros recibida
     * como parámetro
     *
     * @param kilometros - Los kilómetros que se quieren recorrer y para los que
     * hay que calcular si la carga de batería efectiva es sufciente.
     * @return La carga de batería que quedaría disponible tras realizar ese
     * desplazamiento.
     */
    @Override
    public double usarBateria​(double kilometros) {

        //Calculamos qué porcentaje de km. representa ese desplazamiento respecto a la autonomía del coche
        //porcentaje = (this.kilometrosSinRepostar * 100 / (CocheElectrico.MAX_AUTONOMIA - CocheElectrico.MIN_AUTONOMIA)) - this.cargaEfectiva; // Ya que la autonomia real del coche actual seria el máximo km menos el minimo (300km).    
        double porcentaje = this.autonomia / this.capacidadMaximaBateria;
        this.cargaEfectiva = this.cargaEfectiva - (kilometros / porcentaje);
        // Para que no tome valores negativos, ya al llegar a cero estara descargada.
        if (this.cargaEfectiva < 0) {
            this.cargaEfectiva = 0;
        }

        return this.cargaEfectiva;
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaze Enchufable
    // ------------------------------------------------------------
    /**
     * Método de consulta que devuelve el voltaje de la batería del Coche
     * Eléctrico.
     *
     * @return El voltaje de la batería del Coche Eléctrico.
     */
    @Override
    public int getVoltaje() {
        return this.voltajeBateria;
    }

    /**
     * Método para obtener un array de Strings con el listado de países para los
     * que el voltaje es compatible con el de este Coche eléctrico.
     *
     * @return Devuelve un array de Strings con los nombres de los países
     * compatibles según el voltaje de la batería del Coche Eléctrico.
     */
    @Override
    public String[] getPaisesCompatibles() {
        String[] String;

        switch (this.getVoltaje()) {
            case 12: // España y Portugal
                String = LISTA_PAISES_COMPATIBLES[0];
                break;
            case 24: // Francia y Belgica
                String = LISTA_PAISES_COMPATIBLES[1];
                break;
            case 48: // Inglaterra
                String = LISTA_PAISES_COMPATIBLES[2];
                break;
            default:// Por defecto serán 12v (España y Portugal) 
                String = LISTA_PAISES_COMPATIBLES[0];
                break;
        }

        return String;
    }

    // --------------------------------
    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve la representación como String de un Coche Eléctrico
     * con el formato
     *
     * @return
     * <p>
     * La representación como String de un Coche Eléctrico con el formato {
     * Marca: XXX; modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Combustible: VVV;
     * Km. sin repostar: UUU; Kilometraje: TTT; Voltaje: OOO; Capacidad batería:
     * PPP; Carga efectiva: QQQ; Países compatibles: RRR } donde XXX representa
     * la marca, YYY representa el modelo, ZZZ representa el número de serie,
     * WWW representa la fuerza motriz, VVV representa el tipo de combustible
     * usado, UUU representa los km. desde el último respotaje, TTT representa
     * el total de km. recorridos por el coche desde su fabricación, OOO
     * representa el voltaje de la batería, PPP representa la capacidad de la
     * batería, QQQ representa la carga efectiva en ese momento y RRR la lista
     * de países compatibles.</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Voltaje: %d; Capacidad batería: %.2fw; Carga efectiva: %.2f w; Países compatibles: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                this.voltajeBateria,
                this.capacidadMaximaBateria,
                this.cargaEfectiva,
                listaPaises);
    }

}
