package tarea2;

import java.util.Scanner;

/**
 *
 * Ejercicio 2: estaciones y cumpleaños. Una máquina calcula la estación del año
 * en la que nacimos. Para ello necesita conocer la fecha de nuestro cumpleaños.
 *
 * Implementar un programa en Java que solicite al usuario un día (número entero
 * entre 1 y 31) y un mes (número entero entre 1 y 12). Sólo se trabaja con años
 * no bisiestos, es decir, que no se admite la fecha 29 de febrero:
 *
 * si los valores no son correctos para formar una fecha válida (números fuera
 * del rango indicado o bien el día no es coherente con el mes) se indicará que
 * la fecha no es correcta y finalizará el programa; si la fecha es correcta, el
 * programa procederá a calcular a qué estación corresponde esa fecha y lo
 * mostrará por pantalla.
 *
 * Ten en cuenta que:
 * <ul>
 * <li>se valorará que se minimice el número de líneas. Intenta utilizar los
 * operadores lógicos para ir agrupando las condiciones de cada estación en una
 * única sentencia if diferente;</li>
 * <li>antes de comenzar a analizar a qué estación pertenece una fecha, deberías
 * primero comprobar que la fecha es correcta; </li>
 * <li>una vez que se establezca que la fecha pertenece a una estación, no
 * deberías seguir realizando comprobaciones. No es necesario y sería
 * ineficiente. Para ello puedes aprovechar el uso del "if/elseif"; </li>
 * <li>si has hecho la comprobación de tres estaciones y la fecha no corresponde
 * con ellas, no es necesario que hagas una cuarta comprobación. Sería
 * redundante pues sabrás seguro que estás en la cuarta estación, dado que no
 * hay otra posibilidad. Para eso tienes el else; </li>
 * <li>no puedes usar ningún método, ni la API de Java ni propio, en ninguna
 * parte del código. Tampoco se puede usar ninguna clase adicional, ni propia ni
 * del API de Java, para resolver el ejercicio; se deberán utilizar estructuras
 * "if/else" o "if/elseif/else" obligatoriamente.</li>
 * </ul>
 *
 * @author David Lopez Coronel
 */
public class Ejercicio02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes        
        // Variables de entrada
        int dia; // Numero entre 1 y 31.
        int mes; // Será entre 1 y 12.
        // La fecha 29 febrero no se admite como entrada.

        // Variables de salida
        String estacion = "";

        // Variables auxiliares
        boolean fechaValida = true;

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ESTACIONES Y CUMPLEAÑOS");
        System.out.println("-----------------------");

        System.out.print("Introduzca el Día en el que naciste: ");
        dia = teclado.nextInt();
        System.out.print("Introduzca mes en el que naciste: ");
        mes = teclado.nextInt();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        boolean diaAdmitido = (dia >= 1) && (dia <= 31); //Valores admitidos para la entrada de días. (true)
        boolean mesAdmitido = (mes >= 1) && (mes <= 12); //Valores admitidos para la entrada de meses.(true)
        boolean anoBisiesto = (mes == 2) && (dia >= 1) && (dia >= 29); //Para el calculo de año bisiesto.(false)
        boolean mes30dias = ((mes == 4) || (mes == 6) || (mes == 9) || (mes == 11)) && (dia >= 1) && (dia >= 31); //Para condicionar la entrada de los valores de los meses de 30 dias.(false)        

        if (diaAdmitido == false || mesAdmitido == false                        //Con este primer 'if' voy a condicionar el valor de la variable de 'fechaValida'
                || anoBisiesto == true || mes30dias == true) {
            fechaValida = false;
        } else if ((mes == 3 && dia >= 21)                                      //Si se diera que es false, terminaria la ejecución aquí; 
                || mes == 4                                                     //Si el valor de 'fechaValidad' es 'true' pasaremos a comprobar las condiciones para deducir la estación.
                || mes == 5
                || (mes == 6 && dia < 21)) {

            estacion = "PRIMAVERA";
        } else if ((mes == 6 && dia >= 21)
                || mes == 7
                || mes == 8
                || (mes == 9 && dia < 23)) {

            estacion = "VERANO";
        } else if ((mes == 9 && dia >= 23)
                || mes == 10
                || mes == 11
                || (mes == 12 && dia < 21)) {

            estacion = "OTOÑO";
        } else {                                                                //Si no se cumplio ninguna condicion de las anteriores, va ser la estación de 'invierno'.
            estacion = "INVIERNO";
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        if (fechaValida == true) {                                              //Mientras la 'fechaValida' sea 'true' vamos a imprimir la estación.
            System.out.println(" La estación es: " + estacion);
        } else {
            System.out.println("Fecha introducida, no es valida!! ");
        }
    }
}
