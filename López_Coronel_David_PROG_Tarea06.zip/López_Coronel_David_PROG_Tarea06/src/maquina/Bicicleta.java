package maquina;

/**
 * <strong>Bicicleta</strong>
 * Clase que modela una bicicleta como máquina mecánica con capacidad para
 * desplazarse. No se desea que se puedan crear más subtipos de bicicletas. A la
 * información heredada de la clase MaquinaMecanica, añade 3 atributos:
 *
 * <ul>
 * <li>Radio de las ruedas. De tipo double, se mide en centímetros.</li>
 * <li>Total de kilómetros recorridos desde su fabricación. De tipo double.</li>
 * </ul>
 *
 * @author David López Coronel
 */
public final class Bicicleta extends MaquinaMecanica implements Desplazable {

    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    // Atributos estáticos constantes públicos
    // (rangos y requisitos de los atributos de objeto)
    // Son públicos, disponibles para que cualquier código cliente pueda acceder a ellos
    // ---------------------------------------------------------------------------------
    /**
     * El valor por defecto para el radio de la rueda de una bicicleta:
     * {@value DEFAULT_RADIO_RUEDA} cm.
     */
    public static final double DEFAULT_RADIO_RUEDA = 33.0;
    /**
     * El valor mínimo para el radio de una rueda: {@value MIN_RADIO_RUEDA} cm.
     */
    public static final double MIN_RADIO_RUEDA = 17.75;
    /**
     * El valor máximo para el radio de una rueda: {@value MAX_RADIO_RUEDA} cm.
     */
    public static final double MAX_RADIO_RUEDA = 36.85;
    /**
     * El número máximo de kilómetros que se puede desplazar una bicicleta sin
     * hacer paradas: {@value MAX_DESPLAZAMIENTO} km.
     */
    public static final double MAX_DESPLAZAMIENTO = 200.0;

    // ATRIBUTOS DE OBJETO  ////////////////////////////////////////////////////
    // -------------------------------------------------------------------------    
    protected double radioRueda;
    protected double totalKilometros;

    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
    /**
     * Constructor que crea una bicicleta a partir de los valores recibidos como
     * parámetros para marca y modelo, asignándole como radio el valor por
     * defecto, inicializando el contador de total de kilómetros recorridos a 0.
     *
     * @param marca - La marca de la bicicleta.
     * @param modelo - El modelo de la bicicleta.
     */
    public Bicicleta(String marca, String modelo) {
        super(marca, modelo);     

        this.fuerzaMotriz = Fuerza.ANIMAL;
        this.radioRueda = Bicicleta.DEFAULT_RADIO_RUEDA;
        this.totalKilometros = 0;             
    }

    /**
     * Constructor que crea una nueva bicicleta a partir de los valores
     * recibidos como parámetros para marca, modelo y radio de las ruedas. Hace
     * uso para ello del constructor de dos parámetros, que asigna valores a
     * todos los atributos menos al radio.
     *
     * @param marca- La marca de la bicicleta.
     * @param modelo- El modelo de la bicicleta.
     * @param radioRueda- El radio en cm. de la rueda.
     * @throws IllegalArgumentException- cuando el radio de la bicicleta es
     * menor que el valor mínimo definido por MIN_RADIO_RUEDA y mayor que el
     * valor máximo definido por MAX_RADIO_RUEDA.
     */
    public Bicicleta(String marca, String modelo, double radioRueda) throws IllegalArgumentException {
        this(marca, modelo);
        
        // Si el 'radioRueda' no está comprendido entre el siguiente rango establecido.
        if (radioRueda < Bicicleta.MIN_RADIO_RUEDA || radioRueda > Bicicleta.MAX_RADIO_RUEDA) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //Contrarrestamos 'los que no se han creado'.
            Maquina.proximoNumSerie--; 
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Error en valor del radio: %.2f cm. Debe estar comprendido entre: %.2f cm. Y %.2f cm.",
                    radioRueda,
                    Bicicleta.MIN_RADIO_RUEDA,
                    Bicicleta.MAX_RADIO_RUEDA));
        } else {
            // El valor de los parámetros son válidos, así que construimos el objeto                       
            this.radioRueda = radioRueda;                        
            //ATRIBUTO ESTATICO DE CLASE 
            //Hereda de la super clase, por tanto no hay que volver a incrementarlo.
            //Maquina.cantidadMaquinasFabricadas++;            
        }

    }

    // ------------------------------------------------------------
    // Redefinición de los métodos de la interfaz Desplazable
    // ------------------------------------------------------------
    /**
     * Método que aumenta el total de kilómetros recorridos por una bicilceta.
     * No se va a permitir desplazamientos negativos, ni mayores que el máximo
     * fijado por MAX_DESPLAZAMIENTO sin parar en bicicleta.
     *
     * @param kilometros - El total de kilómetros que se desplaza la bicicleta,
     * incrementándose el contador de kilómetros en esa cantidad.
     * @throws IllegalArgumentException - Si el el parámetro kilometros es
     * negativo, o mayor que el desplazamiento máximo.
     */
    @Override
    public void desplazar(double kilometros) throws IllegalArgumentException {
        if (kilometros < 0 || kilometros > Bicicleta.MAX_DESPLAZAMIENTO) {
            // No se crea un objeto.
            // Se lanza una excepción.
            throw new IllegalArgumentException(String.format("Cantidad de kilometros negativa o excesiva (Máx: %.1f km): %.1f km.",
                    Bicicleta.MAX_DESPLAZAMIENTO, kilometros));
        } else {
            this.totalKilometros += kilometros;
        }
    }

    /**
     * Método que devuelve el total de kilómetros que la bicicleta ha recorrido
     * desde su fabricación. Puesto que las bicicletas no necesitan respostar,
     * coincidirá exactamente con el valor devuelto por el método
     * <code>getKilometrosSinRepostar()</code>.
     *
     * @return total de kilómetros que ha recorrido esta bicicleta.
     */
    @Override
    public double getTotalKilometrosRecorridos() {
        return this.totalKilometros;
    }

    /**
     * Método que devuelve el total de kilómetros que ha recorrido la bicicleta
     * sin repostar. Dado que las bicicletas no necesitan repostar, el valor
     * devuelto coincidirá exactamente con el total de kilómetros recorridos por
     * la bicicleta desde su fabricación.
     *
     * @return El total de kilómetros que la bicicleta ha recorrido desde su
     * fabricación.
     */
    @Override
    public double getKilometrosSinRepostar() {
        return this.totalKilometros;
    }
    
    // --------------------------------
    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString

    /**
     * Método que devuelve la representación como String de una bicicleta.
     *
     * @return
     * <p>
     * La representación como String de una bicicleta, con el formato { Marca:
     * XXX; modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Radio: VVV; Kilómetros:
     * UUU } donde XXX representa la marca, YYY representa el modelo, ZZZ
     * representa el número de serie, y WWW representa la fuerza motriz, VVV
     * representa el radio de la rueda y UUU los kilómetros recorridos por la
     * bicicleta</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Radio: %.2f; Kilómetros: %.1f}",
                toStringSuper.substring(0, toStringSuper.length() - 1),
                this.radioRueda,
                this.totalKilometros);

    }

}
