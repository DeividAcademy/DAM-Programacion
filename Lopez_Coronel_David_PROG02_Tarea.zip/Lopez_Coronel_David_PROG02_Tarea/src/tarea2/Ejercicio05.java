package tarea2;

import java.util.Scanner;

/**
 * Ejercicio 5: escalera incremental. Estamos enseñando a un niño a contar y
 * para ello estamos realizando diversos puzzles y juegos para estimular su
 * curiosidad y creatividad.
 *
 * Escribir un programa en Java que solicite por teclado un número de filas
 * (entre 1 y 10) y que genere una cadena de caracteres con una escalera del
 * siguiente tipo: en cada fila habrá una cantidad de números igual al número de
 * filas en las que se esté. Se empezará contando desde el 1 en la primera fila
 * y ese contador se irá "arrastrando" en cada fila sucesiva. Cada número debe
 * ir separado del siguiente por un espacio en blanco. Es decir en la primera
 * fila habrá un único número, el 1, en la segunda dos números (2 y 3), en la
 * tercera tres números (4, 5 y 6) y así sucesivamente 1 tal y como se puede
 * observar en el ejemplo siguiente:
 *
 * 1: 1 2: 2 3 3: 4 5 6 4: 7 8 9 10 5: 11 12 13 14 15 6: 16 17 18 19 20 21
 *
 * Observa que al principio de cada fila se debe escribir el número de fila, dos
 * puntos y la secuencia del contador incrementándose.
 *
 * Si se introduce una cantidad de filas que no se encuentra en el rango
 * permitido (1-10, ambos inclusive), el programa volverá a solicitar la
 * cantidad de filas hasta que ésta sea correcta el número de veces que sea
 * necesario. Para llevar a cabo este control te recomendamos utilizar un bucle
 * do-while.
 *
 * Una vez que se haya construido la cadena con la escalera debes mostrarla por
 * pantalla como resultado final del programa. Para construir la escalera debes
 * utilizar bucles for.
 *
 *
 * @author David López Coronel.
 */
public class Ejercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final int RANGO_MINIMO = 1;     // Recordemos que para declarar las constantes tendremos que poner el 'static final int RANGO_MINIMO = 1;'
        final int RANGO_MAXIMO = 10;   // Bien como ya el'static' lo tenemos declarado en la clase '(public static void main ...)' pues no tendremos que poner el 'static'

        // Variables de entrada
        int numeroFilas; //(Será entre 1 y 10)

        // Variables de salida
        String cadenaCaracteres = "";  //Aqui an la variable String lo iniciamos vacia, para ir añadiendo luego el contenido, sobre la ejecución.

        // Variables auxiliares
        int contadorFilas;
        int incrementoNumeros;
        int sumaNumeros = 0; // En esta variable pretendo(almacenar) ir sumando y arrastrando el numero por filas.

        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ESCALERA INCREMENTAL");
        System.out.println("--------------------");

        do {
            System.out.print("Introduzca el número de filas (que sean entre 1 y 10): ");            //Preguntamos o pedimos los datos de entrada
            numeroFilas = teclado.nextInt();                                                        //entrada por teclado
        } while ((numeroFilas < RANGO_MINIMO) || (numeroFilas > RANGO_MAXIMO));                     //Mientras no se cumpla estos requisitos se volvera a preguntar, hasta este dentro de los valores Minimo(0) y Maximo(10).

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------     
        
        for (contadorFilas = 1; contadorFilas <= numeroFilas; contadorFilas++) {                    //Bucle for; sabiendo que vamos a tener 10 filas, pues con un 'contadorFilas' que comience siempre desde el mínimo o desde abajo (1), pues incremente o suba hasta el máximo numeroFilas en este caso serán <= porque el máximo es 10, pero yo puedo poner menos filas.
            //Fila 1                                                                                //En tal caso si la fila es la 1 entraremos al siguiente proceso o bucle. con el número contador filas nos vamos a guiar para ello.
            if (contadorFilas == 1) {
                cadenaCaracteres += "1: ";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {                    
                    cadenaCaracteres += incrementoNumeros;                                           //Vamos a ir añadiendo los caracteres o números, por filas, a la variable de salida.
                } sumaNumeros += contadorFilas;
                //Fila 2
            } else if (contadorFilas == 2) {
                cadenaCaracteres += "\n" + "2:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {                    
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);                     //Cada vez vayamos a añadir o incrementar un número este lo vamos a sumar con el valor de 'sumaNumeros' que me arrastrara el valor necesario para la cadena de caracteres se incremente de manera correcta.         
                } sumaNumeros += contadorFilas;                                                      //Vamos sumando el valor necesario y lo vamos almacenando en está variable 'sumaNumeros' como hemos dicho, para la siguiente fila cuando haga el incremento.
                //Fila 3        
            } else if (contadorFilas == 3) {
                cadenaCaracteres += "\n" + "3:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);                    
                } sumaNumeros += contadorFilas;
                //Fila 4        
            } else if (contadorFilas == 4) {
                cadenaCaracteres += "\n" + "4:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 5
            } else if (contadorFilas == 5) {
                cadenaCaracteres += "\n" + "5:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 6
            } else if (contadorFilas == 6) {
                cadenaCaracteres += "\n" + "6:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 7
            } else if (contadorFilas == 7) {
                cadenaCaracteres += "\n" + "7:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 8
            } else if (contadorFilas == 8) {
                cadenaCaracteres += "\n" + "8:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 9
            } else if (contadorFilas == 9) {
                cadenaCaracteres += "\n" + "9:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                } sumaNumeros += contadorFilas;
                //Fila 10
            } else {
                cadenaCaracteres += "\n" + "10:";
                for (incrementoNumeros = 1; incrementoNumeros <= contadorFilas; incrementoNumeros++) {
                    cadenaCaracteres += " " + (incrementoNumeros + sumaNumeros);
                }
            }
        }
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println(cadenaCaracteres);
    }
}
