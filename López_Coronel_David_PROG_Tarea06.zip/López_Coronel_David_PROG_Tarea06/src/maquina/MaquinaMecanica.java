package maquina;

/**
 * Clase que representa un subtipo de Máquinas, las <strong>Máquinas
 * mecánicas</strong>. A la información heredada de la clase Maquina, añade un
 * par de atributos:
 * <ul>
 * <li><strong>fuerzaMotriz</strong>. La fuente de energía concreta que usará
 * una máquina mecánica para funcionar. Puede tomar atributos de un tipo
 * enumerado Fuerza, declarado aparte y que representa las diferentes fuentes de
 * energía que puede usar una máquina mecánica. Puede tomar los valores ANIMAL,
 * ELECTRICIDAD, COMBUSTIBLE, VIENTO, CORRIENTE_AGUA.</li>
 * <li><strong>DEFAULT_FUERZA_MOTRIZ</strong>.Representa la fuerza motriz que se
 * asignará por defecto: COMBUSTIBLE.</li>
 * </ul>
 *
 * @author David López Coronel
 */
public abstract class MaquinaMecanica extends Maquina {

    /**
     * Representa la fuente de energía concreta que usará una máquina mecánica.
     */
    Fuerza fuerzaMotriz;

    /**
     * Representa la fuerza motriz que se asignará por defecto:
     * {@value DEFAULT_FUERZA_MOTRIZ}.
     */
    public static final Fuerza DEFAULT_FUERZA_MOTRIZ = Fuerza.COMBUSTIBLE;

    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
    /**
     * Constructor para crear una máquina mecánica a partir de la marca, el
     * modelo y la fuerza motriz recibidos como parámetros.
     *
     * @param marca - La marca de la máquina mecánica.
     * @param modelo - El modelo de la máguina mecánica.
     * @param fuerzaMotriz - La fueraz motriz de la máquina mecánica.
     * @throws NullPointerException Si alguno de los parámetros no es válido
     */
    public MaquinaMecanica(String marca, String modelo, Fuerza fuerzaMotriz) throws NullPointerException {
        super(marca, modelo);
        if (fuerzaMotriz == null) {
            // No se crea un objeto.
            // Se lanza una excepci 
            // Si no se crea, no se deberia incrementar   
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new NullPointerException("Error: null. La fuerza motriz no puede ser nula, debe indicarse una fuerza motriz válida.");
        } else {                             
            this.fuerzaMotriz = fuerzaMotriz;            
        }
    }

    /**
     * Constructor para crear una máquina mecánica a partir de la marca y el
     * modelo recibidos como parámetros, asignando el valor por defecto para
     * fuerza Motriz.
     *
     * @param marca - La marca de la máquina mecánica.
     * @param modelo - El modelo de la máguina mecánica.
     *
     */
    public MaquinaMecanica(String marca, String modelo) {
        this(marca, modelo, MaquinaMecanica.DEFAULT_FUERZA_MOTRIZ);
    }

    // Método Get
    // -----------
    /**
     * Getter del atributo fuerzaMotriz
     *
     * @return Método que devuelve el valor asignado como fuerza motriz a una
     * máquina mecánica.
     */
    public Fuerza getFuerzaMotriz() {
        return this.fuerzaMotriz;
    }

    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve la representación como String de una máquina
     * mecánica.
     *
     * @return
     * <p>
     * La representación como String de una máquina mecánica con el formato {
     * Marca: XXX; modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW } donde XXX
     * representa la marca, YYY representa el modelo, ZZZ representa el número
     * de serie, y WWW representa la fuerza motriz.</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Fuerza Motriz: %-10s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                this.getFuerzaMotriz());
    }
}
