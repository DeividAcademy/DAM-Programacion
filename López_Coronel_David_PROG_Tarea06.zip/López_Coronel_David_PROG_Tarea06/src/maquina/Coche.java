package maquina;

/**
 * Calse abtracta para modelar un Coche como máquina mecánica desplazable.
 * <p>
 * Define un parámetro <code>combustibleUsado</code>, que puede tomar los
 * valores del tipo enumerado <code>TipoCombustible</code>. Valores válidos son
 * GASOLINA, DIESEL O ELECTRICIDAD. Como atributos, añade a los heredados por
 * ser una subclase de máquina mecánica los siguientes:</p>
 * <ul>
 * <li>combustibleUsado. Es el tipo de combustible que usa el Coche.</li>
 * <li>kilometrosSinRepostar. Es la distancia recorrida en km. por el Coche
 * desde que se repostó por última vez.</li>
 * <li>kilometrosTotalesRecorridos. Es la distancia recorrida en km. por el
 * Coche desde su fabricación. por</li>
 * </ul>
 *
 *
 * @author David López Coronel
 */
public abstract class Coche extends MaquinaMecanica implements Desplazable {

    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    // Atributos estáticos constantes públicos
    // (rangos y requisitos de los atributos de objeto)
    // Son públicos, disponibles para que cualquier código cliente pueda acceder a ellos
    // ---------------------------------------------------------------------------------
    /**
     * Máximo desplazamiento sin repostar permitido para cualquier Coche:
     * {@value MAX_DESPLAZAMIENTO} km.
     */
    public static final double MAX_DESPLAZAMIENTO = 1500.0;

    // ------------------------------------------------------------
    //               ATRIBUTOS DE OBJETO (todos privados)
    // ------------------------------------------------------------  
    /**
     * Total de kilómetros recorridos por el Coche sin repostar (desde el
     * repostaje anterior).
     */
    protected double kilometrosSinRepostar;
    /**
     * Total de Km. recorridos por el Coche desde su fabricación.
     */
    protected double kilometrosTotalesRecorridos;
    /**
     * Combustible usado por el Coche.
     */
    protected TipoCombustible combustibleUsado;

    // ------------------------------------------------------------
    //                        CONSTRUCTOR
    // ------------------------------------------------------------
    /**
     * Constructor que crea un nuevo Coche a partir de los valores para su
     * marca, modelo y fuera motriz recibidos como parámetros.
     *
     * @param marca - La marca del Coche.
     * @param modelo - El modelo del Coche.
     * @param fuerzaMotriz - Fuerza motriz del coche. Solo admitirá los valores
     * ELECTRICIDAD y COMBUSTIBLE.
     *
     * @throws NullPointerException - cuando fuerzaMotriz es null.
     * @throws IllegalArgumentException - Cuando se intenta asignar como fuerza
     * motriz un valor no válido para un Coche.
     */
    public Coche(String marca, String modelo, Fuerza fuerzaMotriz) throws NullPointerException, IllegalArgumentException {
        super(marca, modelo, fuerzaMotriz);

        if (fuerzaMotriz.equals(Fuerza.COMBUSTIBLE) || fuerzaMotriz.equals(Fuerza.ELECTRICIDAD)) {
            this.kilometrosSinRepostar = 0;
            this.kilometrosTotalesRecorridos = 0;
            if (fuerzaMotriz.equals(Fuerza.ELECTRICIDAD)) {
                combustibleUsado = TipoCombustible.ELECTRICIDAD;
            }
        } else {
            // No se crea un objeto.
            // Se lanza una excepción.    
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new IllegalArgumentException(String.format("Valor de Fuerza motriz incompatible con un Coche: %s.", fuerzaMotriz));
        }
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaz Desplazable        
    // ------------------------------------------------------------
    /**
     * Método que devuelve el total de kilómetros que se han recorrido desde el
     * último respostaje del Coche.
     *
     * @return El total de kilómetros que ha recorrido este Coche hasta el
     * momento.
     */
    @Override
    public double getKilometrosSinRepostar() {
        return this.kilometrosSinRepostar;
    }

    /**
     * Método que devuelve el total de kilómetros que se han recorrido desde la
     * fabricación del coche. Este método va a estar disponible para todos los
     * coches, sin posibilidad de redefinirlo.
     *
     * @return El total de kilómetros que ha recorrido este coche desde su
     * fabricación.
     */
    @Override
    public final double getTotalKilometrosRecorridos() {
        return this.kilometrosSinRepostar;
    }

    /**
     * Método que establece una manera genérica de desplazar cualquier Coche.
     * <p>
     * Incrementará el número de kilómetros recorridos por el coche en la
     * cantidad indicada por el parámetro kilometros. No se va a permitir
     * desplazamientos negativos ni mayores que el valor expresado por
     * MAX_DESPLAZAMIENTO en ningún Coche. En caso de que el parámetro reibido
     * sea válido, se producirá el desplazamiento y se actualizará el total de
     * kilómetros recorridos por el Coche y el total de kilómetros sin repostar.
     * </p>
     *
     */
    @Override
    public void desplazar​(double kilometros) throws IllegalArgumentException {
        if (kilometros <= 0 || kilometros > Coche.MAX_DESPLAZAMIENTO) {
            //No creamos el objeto
            //Lanzamos una excepción
            throw new IllegalArgumentException(String.format("Cantidad de kilómetros negativa, o excesiva para un Coche (Máx: %.1f.): %.1f km.",
                    Coche.MAX_DESPLAZAMIENTO,
                    kilometros));
        } else {
            //Si los kilometros son validos.
            //Actualizamos los parametros de kilometros Recorridos y sin repostar
            this.kilometrosTotalesRecorridos += kilometros;
            this.kilometrosSinRepostar += kilometros;
        }

    }

    // ------------------------------------------------------------
    //                 Métodos de "ACCIÓN"
    // ------------------------------------------------------------
    /**
     * Método que realiza el repostaje de un Coche. Dada la simplicidad del
     * modelo, simplemente pone a cero el contador de kilómetros sin repostar.
     */
    public void repostar() {
        this.kilometrosSinRepostar = 0;
    }

    // ------------------------------------------------------------
    //            Método abstracto 'TipoCombustible'
    // ------------------------------------------------------------
    /**
     * Método abstracto para garantizar que que cualquier subclase de Coche
     * disponga de este medio de consulta del tipo de combustible.
     *
     * @return El tipo de combustible del coche.
     */
    protected abstract TipoCombustible getTipoCombustible();

    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve la representación como String de un Coche.
     *
     * @return
     * <p>
     * La representación como String de un Coche con el formato { Marca: XXX;
     * modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Combustible: VVV; Km. sin
     * repostar: UUU; Kilometraje: TTT } donde XXX representa la marca, YYY
     * representa el modelo, ZZZ representa el número de serie, WWW representa
     * la fuerza motriz, VVV representa el tipo de combustible usado, UUU
     * representa los km. desde el último repostaje y TTT representa el total de
     * km. recorridos por el coche desde su fabricación.</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Combustible: %s; Km. sin repostar: %.1f }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                this.combustibleUsado,
                this.getKilometrosSinRepostar());
    }

}
