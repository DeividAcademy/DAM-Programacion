package tarea2;

import java.util.Scanner;

/**
 * Ejercicio 4: entrenamiento de natación. Una deportista entrena en la piscina
 * haciendo un largo de ida a estilo crol, un largo de vuelta a estilo espalda,
 * un largo de ida a estilo braza y de nuevo vuelta a estilo espalda, y así
 * sucesivamente.
 *
 * Implementar un programa en Java que solicite al usuario la cantidad de largos
 * que ha hecho la nadadora. Debe estar en el rango 0-50, ambos valores
 * incluidos. Si el valor no está en el rango permitido deberá volverse a
 * solicitar para que se introduzca una cantidad válida. Se permitirá introducir
 * hasta tres valores (tres intentos). Un tercer intento no válido hará que el
 * programa finalice sin calcular nada indicando que se ha superado el máximo de
 * intentos erróneos. Los valores límite del número de largos que se usarán para
 * las comprobaciones (mínimo 0, máximo 50) deben estar almacenados como
 * variables de tipo constante en lugar de usar literales. También debe usarse
 * una variable de tipo constante para almacenar el número máximo de intentos
 * (tres).
 *
 * En el caso de que se haya introducido finalmente una cantidad válida se
 * procederá a componer, utilizando obligatoriamente un bucle, una cadena de
 * caracteres donde se representará el desarrollo de cada uno de los largos que
 * ha realizado la nadadora durante su entrenamiento. La cadena, que se mostrará
 * como resultado de la ejecución del programa, tendrá la siguiente estructura:
 * <ol>
 * <li>Comenzará con una apertura de llave (carácter '{') y un espacio en
 * blanco.</li>
 * <li>Se irá indicando cómo se ha hecho cada largo alternando las palabras
 * “Crol”, “Espalda”, “Braza”, “Espalda”, “Crol”, “Espalda”, etc.</li>
 * <li>Cada palabra debe ir separada de la anterior y de la siguiente por un
 * espacio. Se terminará con un espacio en blanco y el cierre de llave (carácter
 * '}').</li>
 * </ol>
 * Si se introducen cero largos como entrada, implemente se mostrará una lista
 * vacía de largos entre llaves.
 *
 * @author David López Coronel.
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        int NUMERO_MAX_INTENTOS = 3;      // Haber, está es uan constante, ya que el máximo intentos será siempre 3, no va a variar y asi se pide en el ejerccicio que la nombremos; yo justifico que la dejo siendo literal o variable para usarla en el contador de intentos, a riesgo de que me penalice jeje.
        final int MINIMO_LARGOS = 0;     // Recordemos que para declarar las constantes tendremos que poner el 'static final int NUMERO_MAX_INTENTOS = 3;'   
        final int MAXIMO_LARGOS = 50;   // Bien como ya el'static' lo tenemos declarado en la clase '(public static void main ...)' pues no tendremos que poner el 'static'

        // Variables de entrada
        int numeroLargos;               //Está variable alamcenara la entrada por teclado de el número de largos.

        // Variables de salida
        String desarrolloLargos = "";   //La variable sting que contendra el estilo según el caso jeje (Crol, Espalda, Braza, Espalda).

        // Variables auxiliares
        int contadorLargos = 1;
        boolean rangoAdmitido = false;

        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("ENTRENAMIENTO DE NATACIÓN");
        System.out.println("-------------------------");        
       
        do {
            System.out.print(" Introduzca el número de largos realizados (entre 0 y 50): ");
            numeroLargos = teclado.nextInt();
            //Modificamos el valor de la variable contadora(restando intentos, en este caso), para hacer que el
            //bucle pueda seguir iterando hasta llegar a finalizar (no hasta el infinito)
            NUMERO_MAX_INTENTOS--; //Yo le veo mas sentido y utilidad dejandola como literal, en lugar de usar otra varianle; otra opcion es declarar otra variable distinta
        } while (((numeroLargos < MINIMO_LARGOS) || (numeroLargos > MAXIMO_LARGOS)) && (NUMERO_MAX_INTENTOS >= 1)); //Establecemos la condición del bucle 

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------        

        if ((numeroLargos >= MINIMO_LARGOS) && (numeroLargos <= MAXIMO_LARGOS)) { //Si el último número introducido en los intentos cumple estas condiciones,
            rangoAdmitido = true;                                                 //entonces el (rangoAdmitido sera (true)).

            while (contadorLargos <= numeroLargos) {                              //Establecemos la condición del bucle
                switch (contadorLargos % 4) {                                       //Dentro del bucle vamos a dividir el número contadorLargos usando el bucle o selector 'switch'
                    case 1:                                                          //de tal manera que vamos a dividir el contador 1/4 = 0.25 (bien como es mayor a 0 será el caso 1 = Crol)
                        desarrolloLargos += " Crol ";                               //contador=2; entonces 2/4 = 0.5 (será el caso 2 = Espalda)
                        break;                                                     //contador=3; entonces 3/4 = 0.75 (será el caso 3 = Braza)
                    case 2:                                                       //contador=4; entonces 4/4 = 1 (será el caso 0 = Espalda)
                        desarrolloLargos += " Espalda ";                         //De esta manera vemos que lo que hace es fraccionar entre 4 partes y según el resto del operando % pues será un caso u otro jeje
                        break;
                    case 3:
                        desarrolloLargos += " Braza ";
                        break;
                    case 0:
                        desarrolloLargos += " Espalda ";
                }
                contadorLargos++;
            }
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();

        System.out.println(
                "DESARROLLO DE LARGOS");
        System.out.println(
                "--------------------");
        if (rangoAdmitido
                == false) {
            System.out.println("Se ha superado el máximo de intentos erróneos ");
        } else {
            System.out.println("{" + desarrolloLargos + "}");
        }
    }
}
