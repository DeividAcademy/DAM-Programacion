package tarea04;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author David López Coronel.
 */
public class Ejercicio05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final int NUM_COLUMNAS = 6;
        // Variables de entrada 
        String[] listaCombinaciones = { /* Elementos del array */
            "¡Hola Mundo!",
            "primitiva050609123237",
            "La teoría de Filomeno dice…",
            "primitiva121111223344",
            "En un lugar de la Mancha, de cuyo nombre no quiero acordarme…",
            "primitiva123456789012",
            "estoEsunacosa",
            "AbuelitoDimeTu",
            "primitiva010211334549"
        };

        // Variables de salida
        // Variables auxiliares
        boolean cadenaReconocida = false;
        boolean sorteoValido = false;
        int numSorteosValidos = 0;

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LOTERÍA PRIMITIVA");
        System.out.println("-----------------");
        // En este caso no hay entrada de datos pues los tenemos en un array "fijo" en el programa
        // En un caso real ese array se cargaría de un archivo o por la red

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // 2. Definimos un array de MAX_SORTEOS filas y 6 columnas
        int[][] arraySorteos = new int[listaCombinaciones.length][NUM_COLUMNAS];
        //System.out.printf("Reservado array de  filas: \n %s\n", Arrays.deepToString(arraySorteos));     //Solo para depurar.

        // 3. Expresión regular esperada: "primitiva" seguido de 12 dígitos
        Pattern patronPrimitiva = Pattern.compile("(primitiva)([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})");

        // 4. Recorrer el array listaCombinaciones       
        for (int filas = 0; filas < listaCombinaciones.length; filas++) {
            Matcher matcher = patronPrimitiva.matcher(listaCombinaciones[filas]);
            cadenaReconocida = matcher.matches(); // Me devolverá 'true' si la cadena o fila introducida cumple con el pattern. 
            // 4.1. Si el patrón coincide lo mostramos por consola
            if (cadenaReconocida) {
                System.out.printf("Cadena reconocida: %s\n", listaCombinaciones[filas]);

                // 4.2. Obtener los números que empiezan después de la palabra "primitiva"
                long numPrimitiva = Long.parseLong(listaCombinaciones[filas].substring(9));

                // 4.3.Comprobar si son números válidos para la primtiva (está entre 1 y 49)
                int substraerParIni = 9; //Partiendo de la base y sabiendo cual es el patrón a seguir; sabemos que la cadena de caracteres tiene la palabra 'primitiva' antes que los números, por eso empiezo desde la posición 9 de la cadena.
                int substraerPar2 = 11;  //Como yo quiero analizar y sustraer por pares de números, con estas dos variables locales lo hare.
                int contadorParValidos = 0;
                int numRepetidos = 0;
                for (int columna = 0; columna < NUM_COLUMNAS; columna++) {
                    int numValidos = Integer.parseInt(listaCombinaciones[filas].substring(substraerParIni, substraerPar2));
                    if (numValidos >= 1 && numValidos <= 49) {
                        substraerParIni += 2;
                        substraerPar2 += 2;
                        contadorParValidos++;
                    }

                    // 4.4.Si no salió ningún número no válido entonce el sorteo fue válido
                    // a no ser que haya números repetidos..
                    //Hago el siguiente bucle; tomando el valor por columna o (segundo nivel), como sería por ejemplo primero el '5' y lo voy a comparar con los números de las demás columnas de ese segundo nivel.
                    //De manera que, el 5 lo voy a comparar con el (5,6,9,12,32,37). 
                    //Así sucesivamente con cada columna o (segundo nivel) de cada fila o (primer nivel). 
                    //Luego el 6, lo voy a comparar con el (5,6,9,12,32,37). Se va a repetir una vez como mínimo; y a partir de ahí ya estaría repetido más de una vez y la suma total de repeticiones por fila sería mayor a 6.
                    for (int contador = 2; contador < 8; contador++) { // estos contadores van desde 2 (por el primer grupo que contiene el primer número '5') a 8 (para que avance y chequee cada grupo de números).
                        int compararPares = Integer.parseInt(matcher.group(contador));
                        if (numValidos == compararPares) {
                            numRepetidos++;
                        }
                    }
                }

                // 4.5.Comprobar repetidos. Si hay números repetidos la combinación no es válida
                if (contadorParValidos == 6 && numRepetidos == 6) {
                    sorteoValido = true;
                    if (sorteoValido) {
                        numSorteosValidos++;

                        int incrementoG = 2; //Creo está variable local a partir del conocimiento de mi ‘patternPrimitiva’; como el primer grupo es la palabra 'primitiva' lo inicio a partir del grupo 2; donde estarán las dos primeras cifras o números.
                        for (int columna = 0; columna < NUM_COLUMNAS; columna++) {
                            arraySorteos[filas][columna] = Integer.parseInt(matcher.group(incrementoG));
                            incrementoG++;
                        }
                    }
                }
            }
        }
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: SORTEOS VÁLIDOS");
        System.out.println("--------------------------");

        // 5.Escribir los sorteos válidos
        System.out.printf("Hubo %d sorteos válidos:\n", numSorteosValidos);
        int numSorteo = 1;
        for (int fila = 0; fila < arraySorteos.length; fila++) {
            int suma = 0;
            for (int columna = 0; columna < NUM_COLUMNAS; columna++) {
                suma = arraySorteos[fila][columna] + arraySorteos[fila][columna];   //Pues estando en el mismo primer nivel 'fila'; sumamos columnas con columnas 
                //y las que tengan 0 pues no van a superar el siguiente if y de está manera solo imprimo por pantalla las que tenga valores válidos. 
            }
            if (suma > 1) {                
                System.out.printf("Sorteo %d: %s\n", numSorteo, Arrays.toString(arraySorteos[fila]));
                numSorteo++;
            }
        }
    }
}
