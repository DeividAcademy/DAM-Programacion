package maquina;

/**
 * <p>
 * Clase que permite representar una <strong>Calculadora</strong>. Como un tipo
 * especial de Máquina Eléctrica que es recargable, con la particularidad de que
 * en este caso, su batería son pilas. A los atributos heredados de la clase
 * MaquinaElectrica, añade el atributo tipoPila, que tomará su valor de un tipo
 * enumerado TipoPila, siendo válidos para la Calculadora solo algunos de los
 * valores que incluye ese enumerado (pilas AA de 1,5 v. y pilas botón CR1025 de
 * 3 v.
 * </p>
 *
 * @author David López Coronel
 */
public class Calculadora extends MaquinaElectrica implements Recargable {

    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    // Atributos estáticos constantes públicos
    // (rangos y requisitos de los atributos de objeto)
    // Son públicos, disponibles para que cualquier código cliente pueda acceder a ellos
    // ---------------------------------------------------------------------------------
    /**
     * Se establece que toda calculadora debe tener las pilas adecuadas para que
     * cuando se le repongan permitan su uso durante 100 horas. Valor:
     * {@value HORAS_DE_USO}
     */
    public static final double HORAS_DE_USO = 100;
    /**
     * Tipo por defecto para la pila de la calculadora:
     * {@value DEFAULT_TIPO_PILA}
     */
    public static final TipoPila DEFAULT_TIPO_PILA = TipoPila.AA_1_5V;
    /**
     * Por defecto la calculadora estará sin pilas, así que se considera que la
     * pila está agotada, ya que necesita que se le introduzca una nueva pila.
     * Valor por defecto: {@value DEFAULT_PILA_AGOTADA}
     */
    public static final boolean DEFAULT_PILA_AGOTADA = true;

    // ------------------------------------------------------------
    //               ATRIBUTOS DE OBJETO (todos privados)
    // ------------------------------------------------------------  
    /**
     * Atributo de instancia que indica qué tipo de pila usa esta calculadora
     * concreta.
     */
    protected TipoPila tipoPila;
    /**
     * Atributo de instancia que indica cuántas horas de uso lleva la
     * calculadora desde el último cambio de pilas.
     */
    protected double horasDeUso;
    /**
     * Atributo de instancia que toma el valor true cuando la calculadora no
     * tiene pila, o la tiene agotada (necesita una nueva pila), o false en otro
     * caso.
     */
    protected boolean pilaAgotada;
    // Creo está variable privada auxiliar para el tratamiento de las 'horasUsoRestantes'
    private double horasUsoRestantes;

    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
    /**
     * Método Constructor que crea una nueva calculadora de una marca, modelo y
     * tipo de pila. El atributo pilaAgotada recibirá el valor por defecto. El
     * atributo horsaDeUso recibirá el valor 0, puesto que la calculadora aún
     * está sin usar.
     *
     * @param marca - La marca de la Calculadora.
     * @param modelo - El modelo de la Calculadora.
     * @param tipoPila - El tipo de pila de la Calculadora (Valores válidos:
     * AA_1_5V y BOTON_CR1025_3V).
     *
     * @throws NullPointerException - Cuando se intenta asignar como tipo de
     * pila el valor null.
     *
     * @throws IllegalArgumentException- Cuando se intenta asignar un tipo de
     * pila no permitido para una calculadora. Suponemos que las calculadoras
     * solo usan pilas AA de voltio y medio (AA_1_5V) y pilas botón CR1025 de 3
     * voltios (BOTON_CR1025_3V).
     */
    public Calculadora(String marca, String modelo, TipoPila tipoPila) throws NullPointerException, IllegalArgumentException {
        super(marca, modelo);        
        
        if (tipoPila == null) {
            // No se crea un objeto.
            // Se lanza una excepción.
            //si no se crea no se deberia incrementar 
            Maquina.proximoNumSerie--;
            Maquina.cantidadMaquinasFabricadas--;
            throw new NullPointerException(String.format("Error en tipo de pila: %s. El tipo de pila no puede ser nulo.", tipoPila));
        } else if (tipoPila != TipoPila.AA_1_5V && tipoPila != TipoPila.BOTON_CR1025_3V) {
            throw new IllegalArgumentException(String.format("Error en tipo de pila: %s. Las calculadoras solo admiten pilas de tipo %s y %s.",
                    tipoPila,
                    TipoPila.AA_1_5V,
                    TipoPila.BOTON_CR1025_3V));
        } else {           
            this.tipoPila = tipoPila;
            this.pilaAgotada = Calculadora.DEFAULT_PILA_AGOTADA;
            this.horasDeUso = 0;            
        }
    }

    /**
     * Constructor que permite asignar, además de la marca, modelo y tipo de
     * pila de la calculadora, un "estado de la pila", indicando si lleva o no
     * una pila con carga para funcionar.
     *
     * @param marca - La marca de la Calculadora.
     * @param modelo - El modelo de la Calculadora.
     * @param tipoPila - El tipo de pila de la Calculadora (Valores válidos:
     * AA_1_5V y BOTON_CR1025_3V).
     * @param pilaAgotada - true si la calculadora se crea sin pilas, o con
     * pilas agotadas, y false en caso contrario.
     *
     * @throws NullPointerException - Cuando el tipo de pila vale null.
     * @throws IllegalArgumentException - Cuando se intenta asignar un tipo de
     * pila no permitido para una calculadora. Suponemos que las calculadoras
     * solo usan pilas AA de voltio y medio (AA_1_5V) y pilas botón CR1025 de 3
     * voltios (BOTON_CR1025_3V).
     */
    public Calculadora(String marca, String modelo, TipoPila tipoPila, boolean pilaAgotada) {
        this(marca, modelo, tipoPila);
        this.pilaAgotada = pilaAgotada;

        if (!this.pilaAgotada) {
            // si la pila no esta agotada (pila con carga)
            this.horasUsoRestantes = Calculadora.HORAS_DE_USO;
        } else {
            // si la pila esta descagada
            this.horasUsoRestantes = 0;
        }
    }

    // ------------------------------------------------------------
    //    Redefinición de los métodos de la interfaz Recargable      
    // ------------------------------------------------------------
    @Override
    /**
     * Método que permite cargar una calculadora. Al tratarse de calculadoras
     * solo de pilas, la operación consistirá en reponer las pilas usadas con
     * pilas nuevas, actualizando convenientemente el estado de la pila,
     * asignando el valor false al atributo pilaAgotada y reiniciando las horas
     * de uso a cero.
     */
    public void cargar() {
        this.pilaAgotada = false;
        this.horasDeUso = 0;
        this.horasUsoRestantes = Calculadora.HORAS_DE_USO;
    }

    /**
     * Método que devuelve el número de horas de uso restantes para la
     * calculadora, tras haber sido usada el número de horas que se recibe como
     * parámetro.Se estima que todas las calculadoras vienen equipadas con las
     * pilas necesarias para un mismo número de horas de funcionamiento,
     * expresado por la constante de clase HORAS_DE_USO.
     *
     * @param horas - las horas de uso de la calculadora
     * @return Las horas restantes de uso de la calculadora, tras haber sido
     * usada un determinado número de horas.
     */
    @Override
    public double usarBateria(double horas) {
        // Si la pila no está agotada
        if (!this.pilaAgotada) {
            this.horasUsoRestantes = (Calculadora.HORAS_DE_USO - this.horasDeUso) - horas;
            // Para que no tome valores negativos, ya al llegar a cero estara descargada.
            if (this.horasUsoRestantes < 0) {
                this.horasUsoRestantes = 0;
            }
        }
        return this.horasUsoRestantes;
    }

    // --------------------------------
    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve la representación como String de una Calculadora.
     *
     * @return
     * <p>
     * La representación como String de una Calculadora con el formato { Marca:
     * XXX; modelo: YYY; NS: ZZZ; Voltaje: WWW v.; Potencia: VVVV W; Tipo de
     * pila: UUU; Horas de uso restantes: } donde XXX representa la marca, YYY
     * representa el modelo, ZZZ representa el número de serie, WWW representa
     * el voltaje, VVV representa la potencia eléctrica, UUU representa el tipo
     * de pila usado y RRR representa las horas de uso restantes.</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Tipo de pila: %s; Horas de uso restantes: %.2f }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                this.tipoPila,
                this.horasUsoRestantes);
    }

}
