package maquina;

/**
 * <p>
 * Clase que representa un tipo de máquina mecánica, un Molino. Define
 * internamente un enumerado Tipo, con los posibles valores para el atributo
 * tipo de molino en función de cuál sea la fuerza motriz que usa para
 * funcionar. No se desea permitir que esta clase se extienda en el futuro, por
 * lo que se impide la creación de subclases.</p>
 *
 * @author David López Coronel
 */
public final class Molino extends MaquinaMecanica {

    // ATRIBUTOS DE OBJETO  ///////////////////////////////////////
    // -------------------------------------------------------------------------    
    TipoMolino tipoMolino;

    // ------------------------------------------------------------
    //                        CONSTRUCTOR
    // ------------------------------------------------------------
    /**
     * Constructor que crea un nuevo Molino a partir de los valores recibidos
     * mediante los parámetros marca, modelo y fuerza motriz, haciendo uso del
     * constructor. El tipo de molino se asigna en función de la fuerza motriz
     * de dicho molino para que sea congruente.
     *
     * @param marca - La marca del Molino.
     * @param modelo - El modelo del Molino.
     * @param fuerzaMotriz - La fuerza motriz del Molino.
     *
     * @throws NullPointerException - cuando fuerzaMotriz es null.
     * @throws IllegalArgumentException - Cuando se recibe un valor para el
     * argumento fuerzaMotriz que no es ninguno de los recogidos.
     */
    public Molino(String marca, String modelo, Fuerza fuerzaMotriz) throws NullPointerException, IllegalArgumentException {
        super(marca, modelo, fuerzaMotriz);            

        switch (fuerzaMotriz) {            
            case ANIMAL:
                tipoMolino = TipoMolino.FUERZA_ANIMAL;                
                break;
            case COMBUSTIBLE:
                tipoMolino = TipoMolino.A_MOTOR_COMBUSTION;                
                break;
            case CORRIENTE_AGUA:
                tipoMolino = TipoMolino.DE_AGUA;                
                break;
            case ELECTRICIDAD:
                tipoMolino = TipoMolino.ELECTRICO;                
                break;
            case VIENTO:
                tipoMolino = TipoMolino.DE_VIENTO;                
                break;
            default:
                // Por defecto, si no coincide con ningun 'tipoMolino', lanzaremos una IllegalArgumentException.
                Maquina.proximoNumSerie--;
                Maquina.cantidadMaquinasFabricadas--;
                throw new IllegalArgumentException(String.format("Error, Fuerza motriz no válida: %s.", fuerzaMotriz));
        }
    }

    // Método Get
    // -----------
    /**
     * Método que permite obtener el tipo de molino de que se trata.
     *
     * @return La representación como String del tipo de Molino.
     */
    public TipoMolino getTipoDeMolino() {
        return this.tipoMolino;
    }

    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve la representación como String de una máquina
     * mecánica.
     *
     * @return
     * <p>
     * La representación como String de un Molino, con el formato { Marca: XXX;
     * modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Molino de: VVV } donde XXX
     * representa la marca, YYY representa el modelo, ZZZ representa el número
     * de serie, WWW representa la fuerza motriz y VVV representa el tipo de
     * molino.</p>
     */
    @Override
    public String toString() {
        String toStringSuper = super.toString();
        return String.format("%s; Molino de: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
                this.getTipoDeMolino());
    }

}
