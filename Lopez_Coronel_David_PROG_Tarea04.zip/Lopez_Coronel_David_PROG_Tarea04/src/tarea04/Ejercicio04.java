package tarea04;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author David López Coronel.
 */
/**
 * Ejercicio 4: butacas de un teatro.
 *
 * Las butacas de un teatro tienen la siguiente disposición en forma de
 * triángulo:
 *
 * primera fila (la más cercana al escenario): cuatro butacas; segunda fila:
 * seis butacas; tercera fila: ocho butacas; y así sucesivamente hasta la última
 * fila, aumentando dos butacas más en cada fila.
 *
 * El precio de las butacas tendrá la siguiente estructura:
 *
 * -las más baratas serán las de la última fila, a 10,50 euros, salvo las de los
 * dos extremos, que costarán cincuenta céntimos menos (10,00); -según vayamos
 * avanzando filas, acercándonos al escenario, el precio de la butaca se
 * incrementará en cincuenta céntimos, teniendo en cuenta que la butaca de cada
 * extremo es siempre cincuenta céntimos más barata que el precio general de esa
 * fila.
 *
 */
public class Ejercicio04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes              
        // Variables de entrada
        // Variables de salida
        double[][] arrayButacas;

        // Variables auxiliares
        int numFilas = 0;
        //int numColumnas = 0;
        double precios = 10.50; //Precio Base.

        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUTACAS DE UN TEATRO");
        System.out.println("--------------------");

        // 1. Solicitamos por teclado el número de butacas
        do {
            try {
                System.out.print("Introduzca el número de filas (2-50): ");
                numFilas = teclado.nextInt();
            } catch (InputMismatchException error) {
                System.out.println("Error, carácter no válido.");
                teclado.nextLine(); // Para recoger la basura o en este caso el error.
            }

        } while (numFilas < 2 | numFilas > 50);

        // 2. Reservamos espacio para el array
        arrayButacas = new double[numFilas][];

        // 2.1. Reservamos espacio para la primera dimensión (cantidad de filas)
        arrayButacas = new double[numFilas][];

        // 2.2. Resevamos espacio para cada fila (no es una tabla "regular")
        // Crear la estructura de columnas para cada fila
        for (int columnas = 0; columnas < numFilas; columnas++) {
            int numAsientos = 4; //Base de la fila 1 en adelante +2..           

            arrayButacas[columnas] = new double[numAsientos + 2 * columnas];  // Dimensionar las columas de esta fila (añadimos el numero de butacas a cada fila).
        }

        // 3. Mostramos por pantalla el contenido del array que se acaba de crear
        // usando Arrays.deepToString
        System.out.printf("Reservado array de %s filas, cada fila con una cantidad de elementos diferente: \n %s\n", numFilas, Arrays.deepToString(arrayButacas));

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Rellenamos el array con los precios
        //Vamos a calcular los precios primero.
        double incrementoPrecio = numFilas * 0.50;
        precios += incrementoPrecio;

        for (int filas = 0; filas < numFilas; filas++) {
            precios -= 0.50;

            // Precio Butacas Extremos.        
            for (int filas1 = 0; filas1 < arrayButacas.length; filas1++) {
                for (int columnas = 0; columnas < arrayButacas[filas].length; columnas++) {
                    arrayButacas[filas][columnas] = (precios - 0.50);
                }
                // Precio Butacas Centro.        
                for (int filas2 = 0; filas2 < arrayButacas.length; filas2++) {
                    for (int columnas = 1; columnas < arrayButacas[filas].length - 1; columnas++) {
                        arrayButacas[filas][columnas] = (precios);
                    }
                }
            }
        }
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: ESTRUCTURA DE BUTACAS Y PRECIOS POR FILAS");
        System.out.println("----------------------------------------------------");

        // Mostramos el contenido del array elemento a elemento con doble bucle        
        // Recorrido de filas
        for (int filas = 0; filas < arrayButacas.length; filas++) {
            int numAsientos = 4; 
            int numButacas = (numAsientos + 2 * filas);                            // De nuevo vuelvo a generar las columnas o butacas para imprimirlas paso a paso. Si yo intentara tomar la variable  
            System.out.printf("Fila %2s ( %2s butacas): ", filas + 1, numButacas); // con el numero columnas generado en pasos anteriores, pues tomaria el total, pero no asi una a una.
            // Contenido de la fila dibujado en la misma línea                  
            // Recorrido de columnas
            for (numButacas = 0; numButacas < arrayButacas[filas].length; numButacas++) {
                System.out.printf("%.2f ", arrayButacas[filas][numButacas]);
            }
            System.out.println();
        }

    }

}
