/*
* @author David López Coronel
*/
/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 1: palos de la baraja

Al igual que en el apartado 10.4 de la unidad se definen unidades de medida de volumen, crea ahora un pequeño programa en Java 
que defina un enumerado con los nombres de los palos de la baraja española: OROS, COPAS, BASTOS, ESPADAS, 
para posteriormente mostrar por pantalla cada valor del enumerado declarado.
*/

public class Ejercicio1 {
    public enum Palos {OROS, COPAS, BASTOS, ESPADAS };
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes

        // Variables de entrada
                
        // Variables de salida
        Palos paloOro = Palos.OROS ;
        Palos paloCopa = Palos.COPAS ;
        Palos paloBasto = Palos.BASTOS ;
        Palos paloEspada = Palos.ESPADAS ;
        
        // Variables auxiliares

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PLANTILLA DE PROGRAMA ");
        System.out.println("----------------------");
        System.out.println(" Ejercicico 1. Palos de la Baraja Española. ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        System.out.println ("Palo 1: " + paloOro);
        System.out.println ("Palo 2: " + paloCopa);
        System.out.println ("Palo 3: " + paloBasto);
        System.out.println ("Palo 4: " + paloEspada);
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");        
        
    }
    
}