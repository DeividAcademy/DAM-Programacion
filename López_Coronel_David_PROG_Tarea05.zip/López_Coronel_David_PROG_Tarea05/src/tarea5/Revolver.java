package tarea5;

import java.time.LocalDate;
import java.util.Arrays;
import libtarea5.Audio;

// ------------------------------------------------------------
//                   Clase Revolver
// ------------------------------------------------------------
/**
 * Clase que representa un <strong>revólver</strong>.
 * <p>
 * Los objetos de esta clase contienen atributos que que permiten almacenar
 * información sobre:</p>
 * <ul>
 * <li><strong>CNúmero de serie del revólver.</strong> Este valor se establecerá
 * al crear el objeto revólver y ya no podrá cambiar.</li>
 * <li><strong>Tambor del revólver:</strong> balas y casquillos que contiene en
 * cada momento el tambor del revólver, así como su disposición en el tambor y
 * qué orificio del tambor está en cada momento ante el percutor para recibir el
 * impacto al apretar el gatillo del arma. </li>
 * <li><strong>Disparos efectivos</strong> realizados por el revolver a lo largo
 * de su historia. </li>
 * <li><strong>Distancia recorrida total</strong> desde que el objeto se creó
 * (km).</li>
 * </ul>
 * <p>
 * La clase también dispone de información general independiente de los objetos
 * concretos que se hayan creado. Es el caso de:</p>
 * <ul>
 * <li><Strong>Número de disparos totales</Strong> realizados por todos los
 * revólveres hasta el momento actual.</li>
 * <li><Strong>Número de revólveres descargados</Strong> en el momento
 * actual.</li>
 * </ul>
 *
 *
 *
 *
 * @author David López Coronel.
 */
public class Revolver {

    //1.1.- Atributos de la clase.
    // ATRIBUTOS ESTÁTICOS (de clase)   
    // ------------------------------
    // Atributos estáticos constantes y públicos  //////////////////////////////
    /**
     * Mínima capacidad del tambor permitida a la hora de crear un nuevo
     * revólver: {@value MINIMA_CAPACIDAD} balas.
     */
    public static final int MINIMA_CAPACIDAD = 5;    // capacidad mínima del tambor permitida a la hora de crear un nuevo revólver (5 balas).  
    /**
     * Máxima capacidad del tambor permitida a la hora de crear un nuevo
     * revólver: {@value MAXIMA_CAPACIDAD} balas.
     */
    public static final int MAXIMA_CAPACIDAD = 10;   // capacidad máxima del tambor permitida a la hora de crear un nuevo revólver (10 balas).
    /**
     * Valor por omisión para la capacidad del tambor de un nuevo revólver
     * {@value DEFAULT_CAPACIDAD} balas.
     */
    public static final int DEFAULT_CAPACIDAD = 6;   // valor por omisión para la capacidad del tambor de un nuevo revólver (6 balas).
    /**
     * Último número de serie que se puede crear por año
     * {@value MAXIMO_NUM_SERIE}.
     */
    public static final int MAXIMO_NUM_SERIE = 99;   // se podrán construir 99 revólveres por año.

    // Atributos estáticos variables, y privados ///////////////////////////////
    private static int numTotalDisparos;             // cantidad total de balas disparadas por todos los revólveres hasta el momento.
    private static int numRevolveresDescargados;     // cantidad total de revólveres descargados en el momento actual.
    private static int proximoNumSerie = 01;         // cada vez que se cree un nuevo objeto revólver desde un constructor; se debe incrementar +1.  
   
    // ATRIBUTOS DE OBJETO  ////////////////////////////////////////////////////
    // -------------------------------------------------------------------------    
    // Atributos de naturaleza inmutable   /////////////////////////////////////   
    private final String numSerie;      // representará el año en el que se ha creado(2020,2021,2022, etc.); y 'proximoNumSerie' será un identificadpr secuencial que irá de 01 a 99 por años.    
    private final String tambor[];       // lo implementare en un array de tamaño la capacidad del tambor.

    // Atributos variables  ////  
    private int balasDisparadas;      // balas disparadas por el arma desde que se creó hasta el momento.         
    private int posicion;             // para poder saber qué orificio del tambor está colocado ante el percutor.    

    String año = LocalDate.now().toString();    //variable que proporcionara el año al numSerie.

    // CONSTRUCTORES
    // -------------
    /**
     * Un constructor con un parámetro: capacidad del tambor (número de balas).
     *
     * @param capacidad Capacidad del tambor (número de orificios).
     *
     * @throws IllegalArgumentException Si la capacidad del tambor no está
     * dentro del rango permitido. Mínimo {@value MINIMA_CAPACIDAD}, máximo
     * {@value MAXIMA_CAPACIDAD}.
     *
     * @throws IllegalStateException Si se ha llegado al límite de números de
     * serie que se pueden generar durante el año actual.(Va desde el 01 al
     * {@value MAXIMO_NUM_SERIE}).
     */
    //1.2.- Constructores y métodos "fábrica"
    public Revolver(int capacidad) throws IllegalArgumentException, IllegalStateException {

        // Comprobación de que los parámetros son válidos
        if (capacidad < Revolver.MINIMA_CAPACIDAD || capacidad > Revolver.MAXIMA_CAPACIDAD) {
            // Alguno de los parámetros de construcción no es válido
            // No se crea un objeto Revólver.
            // Se lanza una excepción.
            throw new IllegalArgumentException(String.format("Parámetros de creación del revólver inválidos. Capacidad del tambor: %s", capacidad));
        } else if (Revolver.proximoNumSerie >= Revolver.MAXIMO_NUM_SERIE) {
            throw new IllegalStateException(
                    String.format("Se ha alcanzado  la cantidad máxima de registros que se pueden crear este año %s: %02d", año.substring(0, 4), proximoNumSerie));
        } else {
            // El valor de los parámetros son válidos, así que construimos el objeto

            // Inicialización de los atributos constantes (características "inmutables" del objeto)                
            this.numSerie = String.format("%s-%02d", año.substring(0, 4), Revolver.proximoNumSerie);
            this.tambor = new String[capacidad];

            // Inicialización de los atributos variables de objeto ("estado" del objeto)              
            this.balasDisparadas = 0;
            this.posicion = 0;

            // Actualización de los atributos variables de clase (estáticos)
            Revolver.proximoNumSerie++;
            Revolver.numTotalDisparos = 0;
            Revolver.numRevolveresDescargados++;
        }
    }

    /**
     * Un constructor copia con un parámetro: objeto Revólver que se desea
     * clonar, con las mismas características que el que se ha pasado como
     * parámetro. El nuevo objeto tendrá el tambor vacío y un nuevo número de
     * serie.
     *
     *
     * @param r Objeto que se va a usar para realizar la copia del revólver.
     *
     * @throws IllegalStateException Si se hubiera llegado al límite de números
     * de serie para el año actual.
     */
    //1.2.- Constructores y métodos "fábrica"
    public Revolver(Revolver r) throws IllegalStateException {
        this.numSerie = String.format("%s-%02d", año.substring(0, 4), Revolver.proximoNumSerie);
        this.tambor = r.tambor;
        this.balasDisparadas = 0;
        Revolver.numRevolveresDescargados++;
        Revolver.proximoNumSerie++;
    }

    /**
     * Un constructor sin parámetros. En este caso se instanciará un objeto
     * <Strong>Revólver</Strong> con un tambor con la capacidad por omisión
     * {@value DEFAULT_CAPACIDAD}.
     *
     * @throws IllegalStateException Que "heredaría" de la invocación al
     * constructor con un parámetro si se hubiera llegado al límite de números
     * de serie.
     *
     */
    //1.2.- Constructores y métodos "fábrica"
    public Revolver() throws IllegalStateException {
        this(Revolver.DEFAULT_CAPACIDAD);
    }

    /**
     * Un método "fábrica" crearRevolverCargado. Crea un nuevo objeto Revolver
     * con el tamaño de tambor indicado en el parámetro y cargado de balas.
     *
     * @param capacidad capacidad del tambor.
     * @return Revólver con tambor del tamaño indicado y cargado.
     * @throws IllegalStateException
     * @throws IllegalArgumentException
     *
     */
    //1.2.- Constructores y métodos "fábrica"
    public static Revolver crearRevolverCargado(int capacidad) {
        Revolver c;
        //cargar();        
        Revolver.numRevolveresDescargados--;
        c = new Revolver(capacidad);
        return c;
    }

    /**
     * Un método "fábrica" sin parámetros, en este caso se crearía también un
     * nuevo revólver cargado pero con un tambor con la capacidad por omisión
     * {@value DEFAULT_CAPACIDAD}.
     *
     * @return Revólver con tambor del tamaño por omisión y cargado.
     * @throws IllegalStateException
     *
     */
    //1.2.- Constructores y métodos "fábrica"
    public static Revolver crearRevolverCargado() throws IllegalStateException {
        /*
        String bala = "X";        
        for (int i = 0; i < this.tambor.length; i++) {
            this.tambor[i] = bala;
        }
        //Arrays.fill(tambor, bala); // Usando 'Arrays.fill' relleno el array tambor completamente con el valor 'vacio'. (De manera que este método me rellena un array con valor (seleccionado)).
        */
        Revolver.numRevolveresDescargados--;
        return new Revolver(Revolver.DEFAULT_CAPACIDAD);
    }

    // MÉTODOS CONSULTORES (o "getters")
    // ---------------------------------
    /**
     *
     * @return Devuelve el número de serie del revólver.
     */
    //1.3.- Métodos de consulta
    public String getNumSerie() {
        return this.numSerie;
    }

    /**
     *
     * @return Devuelve la capacidad del tambor del revólver.
     */
    public int getCapacidad() {
        return this.tambor.length;
    }

    /**
     *
     * @return Devuelve la cantidad de balas que contiene actualmente el tambor
     * del revólver.
     */
    public int getNumBalas() {
        int numBalas = 0;
        String bala = "X";
        for (int i = 0; i < this.tambor.length; i++) {
            if (bala.equals(this.tambor[i])) {
                numBalas++;
            }
        }
        return numBalas;
    }

    /**
     *
     * @return Indica si el revólver se encuentra totalmente descargado, es
     * decir, si no contiene ni una sola bala "disparable".
     *
     */
    public boolean isDescargado() {
        boolean descargado = true;
        String bala = "X";
        for (int i = 0; i < this.tambor.length; i++) {
            String orificio = this.tambor[i];
            if (orificio == bala) {
                descargado = false;
            }
        }
        return descargado;
    }

    /**
     *
     * @return Devuelve la cantidad de disparos efectivos realizados por el
     * revólver desde que se creó.
     */
    public int getNumDisparos() {
        return this.balasDisparadas;
    }

    /**
     *
     * @return Devuelve la cantidad de disparos efectivos realizados por todos
     * los revólveres hasta el momento.
     */
    public static int getNumTotalDisparos() {
        return Revolver.numTotalDisparos;
    }

    /**
     *
     * @return Devuelve la cantidad de revólveres descargados que hay en el
     * momento actual.
     */
    public static int getNumRevolveresDescargados() {
        return Revolver.numRevolveresDescargados;
    }

    // MÉTODOS DE ACCIÓN
    // -----------------  
    /**
     * Carga el revólver con una determinada cantidad de balas. Se va
     * recorriendo el tambor desde su posición 0 y se van introduciendo
     * proyectiles en los orificios que aún no tengan bala (tanto si hay hueco
     * como si hay casquillo). Si en algún orificio ya hay una bala aún sin
     * utilizar, se pasa al siguiente orificio. Si sobran balas, simplemente no
     * se tienen en cuenta. Se devolverá el número de balas que efectivamente se
     * han introducido en el tambor.
     *
     * @param numBalas Número de balas con las que se quiere cargar el revólver.
     * @return Devolverá el número de balas que efectivamente se han introducido
     * en el tambor (número entero), que podría ser menor que el número de balas
     * con las que inicialmente se intenta cargar.
     *
     * @throws IllegalArgumentException Si se proporcionara una cantidad de
     * balas negativa.
     */
    //1.4.- Carga del arma
    public int cargar(int numBalas) throws IllegalArgumentException {
        int cargaEfectiva = 0;
        String bala = "X";
        String orificio;

        if (numBalas < 0 || numBalas > this.tambor.length) {
            // Si se proporcionara una cantidad negativa o mayor a la capacidad del tambor.
            // Lanzamos excepción
            throw new IllegalArgumentException(String.format("Cantidad de balas inválida: %d", numBalas));
        } else {
            for (int i = 0; i < numBalas; i++) { // A tener en cuenta el array va desde 0.
                orificio = this.tambor[i];
                if (orificio == bala) { // Si tengo una bala ya en el orificio simulo no hacer nada de la siguiente manera, sumando ++ a 'numBalas' para avanzar una posicion más en el tambor del revolver.
                    numBalas++;
                }
                if (orificio != bala) {
                    this.tambor[i] = bala;
                    cargaEfectiva++;
                }
            }
        }
        if (cargaEfectiva > 0) {
            Revolver.numRevolveresDescargados--; // Si hemos cargado alguna bala, nuestro revólver dejara de estar descargado.
        }
        return cargaEfectiva;
    }

    /**
     * Recargar el 'tambor' del Revólver.
     *
     * Versión sobrecargada, sin parámetros, que cargará completamente el tambor
     * con todas las balas que sean necesarias.
     *
     * @return Cantidad de balas que se han podido introducir efectivamente en
     * el tambor.
     */
    //1.4.2.- Carga del arma.Sobrecarga del método.
    public int cargar() throws IllegalArgumentException {
        int cargaEfectiva = 0;   // Balas cargadas en el tambor, de manera efectiva.
        String orificio;
        String vacio = "_";
        String casquillo = "x";
        String bala = "X";

        // accediendo a los orificios del array 'TAMBOR'
        for (int i = 0; i < this.tambor.length; i++) {
            orificio = this.tambor[i];   // Para extraer el objeto q haya dentro de cada posición del tambor. 
            if (orificio != bala) {
                this.tambor[i] = bala;
                cargaEfectiva++;
            }
        }
        Revolver.numRevolveresDescargados--; // Cargamos completamente el revólver, por tanto restamos en uno;
        return cargaEfectiva;
    }

    /**
     * Descarga el tambor del revólver completamente. Se vacía completamente el
     * tambor del revólver, tanto de casquillos como de proyectiles sin
     * utilizar.
     *
     * @return Cantidad de balas (no casquillos) que había en el tambor.
     */
    //1.5.- Descarga del arma.
    public int descargar() {
        int balasDescargadas = 0;
        String vacio = "_";
        String bala = "X";
        String orificio;

        for (int i = 0; i < this.tambor.length; i++) {
            orificio = this.tambor[i];
            if (orificio == bala) {
                balasDescargadas++;
            }
        }
        Arrays.fill(tambor, vacio); // Usando 'Arrays.fill' relleno el array tambor completamente con el valor 'vacio'. (De manera que este método me rellena un array con valor (seleccionado)).
        Revolver.numRevolveresDescargados++; // Descargamos o vaciamos el revólver, pues tenemos que incrementar en uno.
        return balasDescargadas;
    }

    /**
     * Se dispara el revólver pulsando el gatillo. Si el orificio del tambor que
     * había en ese momento ante el percutor contenía un proyectil (bala), se
     * producirá un disparo efectivo. Si el orificio estaba vacío o contenía un
     * casquillo, no se producirá un disparo efectivo. En cuaqluier caso el
     * tambor girará de izquierda a derecha una posición y se colocará el
     * siguiente orificio ante el percutor.
     *
     * @return Si el disparo ha sido o no efectivo.
     */
    //1.6.- Disparo del arma.      
    public boolean disparar() {
        boolean disparo = false;
        String bala = "X";
        String casquillo = "x";
        String vacio = "_";
        String orificio = this.tambor[posicion];

        if (orificio == bala) {
            disparo = true;
            this.balasDisparadas++; //Disparo efectivo, me incrementaría el número disparos con el objeto revólver.
            Revolver.numTotalDisparos++; // //Disparo efectivo, me incrementaría el número disparos realizados con todos los revólveres.
            //En el orificio de la bala disparada, debo cambiar su estado a (bala vacía) o 'casquillo'
            this.tambor[posicion] = casquillo;

        }
        this.posicion++; // Cada disparo efectivo o no, incrementara una posición. 
        if (this.posicion == this.tambor.length) { // Si posición llega al limite o último orificio del tambor; lo reiniciaremos a cero, para simular el giro del tambor.
            this.posicion = 0;
        }
        // Demos saber la situación o el estado de nuestro revólver o mas concretamente lo que tenemos en nuestro tambor tras disparar, ya que implica cambios de estados.
        // Si está cargado o descargado, para incrementar o restar la variable 'Revolver.numRevolveresDescargados'.
        int numBalas = 0;
        int numVacios = 0;
        String orificio2;

        // Con este primer bucle, comprobare si en los orificios de mi tambor tengo valores 'null' o 'vacíos'.
        // De esta manera, si todos mis orificios resultan 'vacíos' o 'null' los almacenare en 'numVacios'.
        // Sí 'numVacios' resulta igual a la longitud del tambor (número de orificios), entonces este aún no se ha cargado nunca
        //    y no debo modificar el valor de "Revolver.numRevolveresDescargados"·
        //
        for (int i = 0; i < this.tambor.length; i++) {
            orificio2 = this.tambor[i];
            if (orificio2 == null || orificio2 == vacio) {
                numVacios++;
            }
        }
        if (numVacios != this.tambor.length) { // Si, 'numVacios' es distinto de (número orificios de mi tambor), entonces puede o contiene balas, casquillos...
            // Otro segundo bucle, para comprobrar la cantidad de balas me quedan en el tambor o revólver.
            for (int j = 0; j < this.tambor.length; j++) {
                orificio2 = this.tambor[j];
                if (orificio2 == bala) {
                    numBalas++;
                }
            }
            if (numBalas < 1) { // Si, 'numBalas' es menor a 1, significará que mi tambor quedo sin proyectiles o balas, por tanto queda descargado.
                Revolver.numRevolveresDescargados++;
            }
        }

        return disparo;
    }

    /**
     *
     * @return
     * <p>
     * Devuelve una cadena que representa el estado de un revolver. El resultado
     * devuelto representará el contenido del tambor y tendrá la siguiente
     * estructura: :</p>
     * <ol>
     * <li>un inicio de bloque o llave (carácter '{');</li>
     * <li>un carácter de tipo '_', 'X' o 'x' por cada orificio del tambor:
     * <ul>
     * <li>si el orificio está vacío aparecerá el carácter '_' (guion bajo o
     * "subrayado");</li>
     * <li>si el orificio contiene una bala completa (no disparada), aparecerá
     * el carácter 'X' (equis mayúscula);</li>
     * <li>si el orificio contiene un casquillo (bala disparada), aparecerá el
     * carácter 'x' (equis minúscula);</li>
     * </ul>
     * </li>
     * <li>un fin de bloque o llave (carácter '}').</li>
     * </ol>
     * <p>
     * Además, el orificio que se encuentre en ese momento delante del percutor
     * deberá aparecerá encerrado entre corchetes (caracteres '[' y ']'). Así
     * quedará claro el orificio sobre el que va a impactar el percutor la
     * próxima vez que se apriete el gatillo al disparar.
     * </p>
     * <p>
     * Aquí tienes un posible ejemplo de salida: { x [X] X X _ _ _ _ }, donde
     * observamos que: </p>
     * <ul>
     * <li>se trata de un revólver con un tambor de capacidad para ocho
     * proyectiles;
     * <li>en el primer orificio hay un casquillo;</li>
     * <li>en los orificios segundo, tercero y cuarto hay balas que aún no han
     * sido disparadas;</li>
     * <li>los orificios del quinto al octavo se encuentran aún vacíos;</li>
     * <li>el percutor se encuentra sobre el segundo orificio.</li>
     * </ul>
     */
    @Override
    public String toString() {
        // La cadena se irá construyendo sobre un objeto StringBuilder         
        StringBuilder resultado = new StringBuilder();

        // 1.Fila cabecera, inicio de bloque ('{').
        resultado.append("{");
        // 2. Caracteres tambor ('_', 'X', 'x')      
        ///////////////////////////////////////////////////
        String vacio = "_";
        String casquillo = "x";
        String bala = "X";
        String orificio; 
        
        // Hare un bucle, para recorrer el array 'tambor' y comprobar el contenido de cada orificio del revólver.
        // Comparando 'i' con 'this.posicion' obtendré y sabré en que orificio estará el percutor.
        for (int i = 0; i < tambor.length; i++) {
             orificio = this.tambor[i]; 
            if (orificio == vacio || orificio == null) {
                if (i == this.posicion) {
                    resultado.append(String.format("[%s]", vacio));
                } else {
                    resultado.append(String.format(" %s ", vacio));
                }
            } else if (orificio == casquillo) {
                if (i == this.posicion) {
                    resultado.append(String.format("[%s]", casquillo));
                } else {
                    resultado.append(String.format(" %s ", casquillo));
                }
            } else {
                if (i == this.posicion) {
                    resultado.append(String.format("[%s]", bala));
                } else {
                    resultado.append(String.format(" %s ", bala));
                }
            }
        }

        ////////////////////////////////////////////////////
        // 3.Fila. Fin de bloque ('}').
        resultado.append(String.format("%s", "}"));

        // Devolvemos la cadena construida*/
        return resultado.toString();
    }

}
