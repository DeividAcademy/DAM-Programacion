/*
 * Clase Maquina
 */
package maquina;

/**
 * <strong>Clase abstracta para representar una Máquina</strong>.
 * <p>
 * Toda máquina va a disponer de tres atributos: numeroDeSerie, marca y modelo,
 * cuyo valor no va a cambiar una vez asignados. El número de serie será un
 * número entero secuencial, que usaremos para cualquier tipo de máquina que
 * fabriquemos. La marca y el modelo son solo dos cadenas de caracteres.
 * Dispondrá de métodos para consultar estos atributos, pero no para
 * modificarlos, ya que no estará permitido una vez que se les asigna un valor
 * al fabricar la máquina.
 * </p>
 *
 * @author David López Coronel
 *
 */
public abstract class Maquina {
    // ---------------------------------------
    // ATRIBUTO ESTÁTICO (de clase, variables)   
    // ---------------------------------------    
    /**
     * La cantidad de máquinas fabricadas será un valor privado de la clase. No
     * nos interesa que se pueda acceder directamente a él desde otras clases,
     * solo lo usamos como contador para asignar el número de serie a cada nueva
     * máquina fabricada. Puede consultarse con el correspondiente método get
     * para saber el total de máquinas fabricadas en un momento dado.
     */
    public static int cantidadMaquinasFabricadas;
    
    protected static int proximoNumSerie = 0; // Atributo auxiliar para incrementar el 'numeroSerie'
    // ---------------------------------------
    //          ATRIBUTOS DE OBJETO  
    // ---------------------------------------
    /**
     * La marca de la máquina.
     */
    protected String marca;
    /**
     * El modelo de la máquina.
     */
    protected String modelo;
    /**
     * El número de serie que toda máquina tendrá.
     */
    protected int numeroSerie;
    
    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
    /**
     * Constructor que crea un objeto de tipo Maquina de una marca y modelo
     * determinados.
     *
     * @param marca La marca de la máquina.
     * @param modelo El modelo de la máquina.
     *
     */
    public Maquina(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.numeroSerie = Maquina.proximoNumSerie;
        // Actualizamos atributos estáticos de clase
        Maquina.proximoNumSerie++;
        Maquina.cantidadMaquinasFabricadas++;
    }

    // MÉTODOS CONSULTORES (o "getters")
    // ---------------------------------
    /**
     * Getter del atributo marca
     *
     * @return Permite consultar la marca del objeto que lo invoca.
     */
    public String getMarca() {
        return this.marca;
    }

    /**
     * Getter del atributo modelo
     *
     * @return Permite consultar el modelo del objeto que lo invoca.
     */
    public String getModelo() {
        return this.modelo;
    }

    /**
     * Getter del atributo NumeroDeSerie
     *
     * @return Permite consultar el número de serie del objeto que lo invoca.
     */
    public int getNumeroDeSerie() {
        return this.numeroSerie;
    }

    /**
     * Getter del atributo cantidadMaquinasFabricadas
     *
     * @return Método para obtener el total de máquinas fabricadas.
     */
    public int getcantidadMaquinasFabricadas() {
        return Maquina.cantidadMaquinasFabricadas;
    }

    // MÉTODOS PARA MOSTRAR INFORMACIÓN
    // --------------------------------
    // Método toString
    /**
     * Método que devuelve un String que representa a la máquina con el formato
     * formato { Marca: XXX; modelo: YYY; NS: ZZZ }, donde XXX representa la
     * marca, YYY representa el modelo, y ZZZ representa el número de serie.
     */
    @Override
    public String toString() {
        return String.format("{ Marca: %-10s; modelo: %-10s; NS: %-4d }",
                this.getMarca(),
                this.getModelo(),
                this.getNumeroDeSerie());
    }

}
