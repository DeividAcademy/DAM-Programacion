/**
 * @author David López Coronel
 */

/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 3: análisis de un número.

Escribe un programa en Java que solicite un número entero (sin decimales) y lo analice averiguando lo siguiente:

    si es cero,
    si es positivo,
    si es menor que cien,
    si es par.

Para ello tendrás que utilizar operadores relacionales tales como igual (==), menor que (<), mayor que (>), etc. 
Ten en cuenta que el resultado de la aplicación de estos operadores es un valor de tipo boolean, es decir un valor que será true o false.

Recuerda también que un número es par si es divisible entre dos, es decir, si el resto de la división entera de ese número entre dos es cero. 
En Java dispones del operador módulo (%) para calcular el resto de la división entera.
*/

public class Ejercicio3 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int num ;
        
        // Variables de salida
        int cero = 0;

        // Variables auxiliares

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
       
        System.out.println("Ejercicio 3.\nÁNALISIS DE UN NÚMERO");
        System.out.println("----------------------");
        
        System.out.print("Introduzca un número entero: ");
        num = teclado.nextInt();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
      
        
                
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
                
        System.out.print ("El número es cero: " );
        System.out.println (num == cero);
        System.out.print ("El número es positivo: " );
        System.out.println (num > cero);
        System.out.print ("El número es menor que 100: ");
        System.out.println (num < 100);
        System.out.print ("El número es par: ");
        /* En la función esPar(int numero), lo único que se hace es comprobar si el resto de dividir el número pasado como parámetro entre 2 es 0, 
        siendo el número par, o no es 0 siendo impar. */
        System.out.println (num % 2 == 0);
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");        
        
    }
    
}