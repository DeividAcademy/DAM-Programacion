package tarea04;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * @author David López Coronel.
 */

public class Ejercicio02 {

    /*
    Un almacén de venta de medicamentos a farmacias nos ha pedido que le realicemos un pequeño programa para analizar los pedidos que reciben.
    
    El programa simplemente debe:

    1-Declarar el array de cadenas con la información anterior.
    2-Ir recorriendo ese array de cadenas que hemos declarado para:
        2.1.Con el elemento de la iteración actual hay que comprobar, utilizando una expresión regular, si esa línea cumple con el patrón adecuado.
        2.2.Si cumple con el patrón, se generará una línea de texto del tipo "Código de farmacia: XXX Producto: YYY ZZZ de VVV gramos. 
            Unidades pedidas: WWW", donde XXX será el código de farmarcia, YYY el código de producto, ZZZ el nombre del medicamento, VVV los gramos del producto y WWW las unidades que se piden. 
            Cada una de esas líneas de texto se irán almacenando en una cadena resultado de tipo StringBuilder que iremos construyendo y que se mostrará por consola al final del programa (en la salida de resultados).
        2.3.Si el elemento del array no cumple con el patrón, simplemente se descartará y no se tendrá en cuenta para la generación del resultado final.
    3-Mostrar por la pantalla el texto final con una línea por cada pedido válido.
     */
    /**
     * @param args
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada      
        // Array de cadenas a procesar.
        // Podríamos considerarlo de "entrada" aunque en este caso es "fijo", ya que 
        // estamos simulando lo que nos llegaría por la red.
        String[] datos = { /* Elmentos del array */
            "00102:715242 GELOCATIL:650:6", //pedido0
            "00102:712786 ASPIRINA:20:4", //pedido1
            "línea errónea", //pedido2
            "0xa", //pedido3
            "53756:844035 FRENADOL:500:10" //pedido4
        };

        // Variables de salida
        StringBuilder strb = new StringBuilder("");

        // Variables auxiliares
        boolean pedidoCorrecto;
        Pattern patronPedidos;
        Matcher matcher;

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PEDIDOS DE FARMACIAS");
        System.out.println("--------------------");
        // En este caso no hay entrada de datos pues los tenemos en un array "fijo" en el programa
        // En un caso real ese array se cargaría con valores obtenidos a través de la red

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //Verificación de pedidos.        
        /*
        La expresión regular que definas para la comprobación de cada medicamento debe cumplir con el siguiente patrón:

        5 dígitos para representar el código de la farmacia.                    
        6 dígitos del código del medicamento.
        Entre 1 y 15 letras del nombre del medicamento.
        Entre 1 y 3 dígitos para indicar los gramos del producto.
        Entre 1 y 4 dígitos para denotar las unidades que se piden.

         */
                                          /*codFarmacia*//*codMedicamento*//*nombMedica*//*g*//*unidades*/
        patronPedidos = Pattern.compile("([0-9]{5}):([0-9]{6}) ([A-Za-z]{1,15}):([0-9]{1,3}):([0-9]{1,4})");
        for (int i = 0; i < datos.length; i++) {
            matcher = patronPedidos.matcher(datos[i]);

            pedidoCorrecto = matcher.matches(); //el método matches() me retornara si es true o false.               
            
            if (pedidoCorrecto) {

                strb.append("Código de farmacia: ").append(matcher.group(1));
                strb.append(" Producto: ").append(matcher.group(2));
                strb.append(" ").append(matcher.group(3));
                strb.append(" de ").append(matcher.group(4)).append(" gramos. ");
                strb.append("Unidades pedidas: ").append(matcher.group(5)).append("\n");
                //strb.append("Unidades pedidas: " +matcher.group(5) + "\n");   //podría haberlo hecho asi concatenando, para cumplir con los requisitos del ejercicio lo hice usando 'append()' 
            }

        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: PEDIDOS VÁLIDOS");
        System.out.println("--------------------------");

        // Mostrar por pantalla el resultado final        
        System.out.printf("%s\n", strb);
        
    }

}
