/**
 * @author David López Coronel
 */

/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 6: reparto de fruta.

En una frutería necesitan un programa para calcular la carga que hacen en sus repartos. De este modo, el programa debe leer los kilogramos de fruta total a repartir.

El camión de reparto hace tres paradas para repartir. Por tanto el programa debe leer:

    la cantidad total de fruta (kilogramos) con la que debe cargarse el camión;
    la cantidad de fruta (kilogramos) que se reparte en cada una de las tres paradas, mostrándose tras cada parada cuánta cantidad queda en el camión.

A partir de esa información se calcularán y mostrarán por pantalla los kilogramos que quedan en el camión una vez finalizado el recorrido del camión.

Puedes usar el operador condicional ? para informar sobre si se repartió toda la fruta o quedó algo por repartir, tal y como se ve en los ejemplos siguientes. 
Ten en cuenta que aún no hemos estudiado las estructuras de control condicionales (como por ejemplo if) y no podemos utilizarlas.
*/

public class Ejercicio6 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          DeclaraciÃ³n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        double kgTotales ;
        double kgParada1 ;
        double kgParada2 ;
        double kgParada3 ;
        
        // Variables de salida
        double kgTotalesResto ;
        
        // Variables auxiliares
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
       
        System.out.println("Ejercicio 6.\nREPARTO DE FRUTA");
        System.out.println("----------------------");
        
        System.out.print("Introduzca los kilogramos totales con los que cargar el camión: ");
        kgTotales = teclado.nextDouble();
        System.out.println();
        System.out.println("Primera parada del camión para repartir. ");
        System.out.print("Introduzca los kilogramos totales que debe repartir en esta primera parada: ");
        kgParada1 = teclado.nextDouble();
        System.out.println ("El camión reparte: " + kgParada1 + " y quedan por tanto por repartir " + (kgTotales - kgParada1) + " kgs.");
        System.out.println();
        System.out.println ("Segunda parada del camión para repartir.");
        System.out.print("Introduzca los kilogramos totales que debe repartir en esta segunda parada: ");
        kgParada2 = teclado.nextDouble();
        System.out.println ("El camión reparte: " + kgParada2 + " y quedan por tanto por repartir " + (kgTotales - kgParada1 - kgParada2) + " kgs.");
        System.out.println();
        System.out.println ("Tercera parada del camión para repartir.");
        System.out.print("Introduzca los kilogramos totales que debe repartir en esta tercera parada: ");
        kgParada3 = teclado.nextDouble();
        System.out.println ("El camión reparte: " + kgParada3 + " y quedan por tanto por repartir " + (kgTotales - kgParada1 - kgParada2 - kgParada3) + " kgs.");
        System.out.println();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        kgTotalesResto = kgTotales - kgParada1 - kgParada2 -kgParada3 ;
                
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
               
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
                
        System.out.print ((kgTotalesResto == 0) ? "Se repartió toda la fruta." : "Quedó algo por repartir." );
        System.out.println ();
        
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");       
        
    }

