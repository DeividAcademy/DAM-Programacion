package tarea04;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author David López Coronel.
 */

/*
En este ejercicio se trata de leer por teclado números binarios, hexadecimales, decimales o egipcios 
(egipcios solo del 1 al 10 y realmente la pronunciación que se cree o se ha deducido, cómo sería en la antigüedad, cuando usaban jeroglíficos). 
En el caso de los números egipcios solo consideraremos la pronunciación de los primeros diez números.
 */
public class Ejercicio03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String lecturaTeclado = "";

        // Variables de salida
        // Variables auxiliares
        boolean fin;        
        int numError = 0;
        int numEgip = 0;
        int numBin = 0;
        int numHex = 0;
        int numDec = 0;
        

        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //     Entrada de datos + Procesamiento
        //----------------------------------------------
        System.out.println("SISTEMAS DE NUMERACIÓN");
        System.out.println("----------------------");

        // 1. Creación del StringBuilder: cadena donde se irán almacenando los resultados válidos
        StringBuilder strb = new StringBuilder("");

        // Iterar para leer números e ir acumulando el valor
        do {
            System.out.print("Introduce un número binario, hexadecimal o decimal. O en egipcio sólo del 1 al 10 (fin o end para terminar): ");

            // 2. Lectura de teclado de un número ++ 3. Limpieza del texto leído eliminando los espacios anteriores y posteriores, y después, conviértelo todo a minúsculas.
            lecturaTeclado = teclado.nextLine().trim().toLowerCase();

            // Conversión del número
            // 4. Comprobamos si es un número egipcio
            Pattern patternEgipcio = Pattern.compile("(ua)?(senua)?(jemet)?(fedua)?(diua)?(sersua)?(sefje)?(hemen)?(pesed)?(medju)?"); //Tengo 10grupos que van del grupo 1 al 10.
            Matcher matcherEgipcio = patternEgipcio.matcher(lecturaTeclado);
            boolean numEgipcio = matcherEgipcio.matches(); //el método matches() me retornara si es true o false.       

            // 4.1. En caso afirmativo efectuamos la conversión
            int numGrupo = patternEgipcio.flags();// Con el '.flags()' me retornara el grupo que resultó true respecto a mi patternEgipcio. 

            if (numEgipcio) {
                String[] egipDec = {"ua", "senua", "jemet", "fedua", "diua", "sersua", "sefje", "hemen", "pesed", "medju"}; //Array números Egipcios. Recordar la longitud del array es los elementos -1 ya que van desde el 0 el primer elemento u objeto.
                for (int contador = 0; contador < egipDec.length; contador++) {

                    // 4.2. Añadimos al resultado el texto con el tipo de conversión           
                    if (egipDec[contador].equalsIgnoreCase(matcherEgipcio.group(numGrupo))) {
                        strb.append(" EGIP a DEC(").append(matcherEgipcio.group(numGrupo)).append("->").append((contador + 1)).append(")\n");
                        numEgip += (contador + 1);
                    }
                }
            }
            // 5. Comprobamos si es un número binario
            Pattern patternBinario = Pattern.compile("(0b)(0|1)+");
            Matcher matcherBinario = patternBinario.matcher(lecturaTeclado);
            boolean numBinario = matcherBinario.matches();

            // 5.1. En caso afirmativo efectuamos la conversión
            if (numBinario) {
                String binario = lecturaTeclado.substring(2);
                long binLong = Long.valueOf(binario).longValue();   //considero que son variables locales.

                //proceso para pasar de binario a decimal
                int exponente = 0;
                long digito, decimal;
                decimal = 0; //será el equivalente en base decimal
                while (binLong != 0) {
                    //se toma la última cifra
                    digito = binLong % 10;
                    //se multiplica por la potencia de 2 correspondiente y se suma al número                          
                    decimal += digito * (int) Math.pow(2, exponente);
                    //se aumenta el exponente
                    exponente++;
                    //se quita la última cifra para repetir el proceso
                    binLong = binLong / 10;
                }

                // 5.2. Añadimos al resultado el texto con el tipo de conversión
                strb.append("BIN a DEC(").append(matcherBinario.group()).append("->").append(decimal).append(")\n");
                numBin += decimal;               

            }
            // 6. Comprobamos si es un número hexadecimal
            Pattern patternHexa = Pattern.compile("(0x)(([0-9])*([a-f])*([0-9])*)+");
            Matcher matcherHexa = patternHexa.matcher(lecturaTeclado);
            boolean numHexa = matcherHexa.matches();

            // 6.1. En caso afirmativo efectuamos la conversión
            if (numHexa) {
                //En esta ocasión uso para la conversión el método '.parseInt' el cual en solo dos líneas me hara esto, mejor qe en el punto 5 (BIN a DEC).
                String hexa = lecturaTeclado.substring(2);
                int decimal = Integer.parseInt(hexa, 16);

                // 6.2. Añadimos al resultado el texto con el tipo de conversión
                strb.append("HEX a DEC(").append(matcherHexa.group()).append("->").append(decimal).append(")\n");
                numHex += decimal;
            }

            // 7. En cualquier otro caso, hay que intentar convertirlo a entero.
            Pattern patternDec = Pattern.compile("[0-9]+");
            Matcher matcherDec = patternDec.matcher(lecturaTeclado);
            boolean numDecimal = matcherDec.matches();

            // 7.1. Añadimos al resultado el texto con el tipo de conversión
            if (numDecimal) {
                int numEntero = Integer.parseInt(lecturaTeclado);

                // 7.2. Añadir a la salida el número recibido asi como su conversión en formato "(xx->yy)"
                strb.append("DEC a DEC(").append(matcherDec.group()).append("->").append(numEntero).append(")\n");
                numDec += numEntero;
            }

            // 8. Control ante un posible número con formato no válido
            Pattern patternFin = Pattern.compile("((fin)?(end)?)+");
            Matcher matcherFin = patternFin.matcher(lecturaTeclado);
            fin = matcherFin.matches(); //En primera instancia quise hacer el patternFin y demás.. en el punto 9. Pero para añadir la condición y no me saliera el print de número no valido lo declare aquí.

            if (!numEgipcio && !numBinario && !numHexa && !numDecimal && !fin) {
                System.out.println("ERROR: número no válido.");
                
                numError += 1;
            }

            // 9. Se seguirán leyendo números hasta que el usuario tecle "fin" o "end"
        } while (!fin);
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        // 10. Mostramos los resultados
        System.out.println();
        System.out.println("RESULTADOS: CONVERSIÓN EN DIFERENTES SISTEMAS DE NUMERACIÓN");
        System.out.println("-----------------------------------------------------------");

        System.out.printf("%s", strb);
        System.out.printf("Entradas erróneas: %d\n", numError); 
        System.out.printf("La suma total de los números leídos sería de: %d\n", (numEgip + numBin + numHex + numDec + numError)); //Estoy realizando operaciones (sumas), cosa que es distinto a usar el simbolo + para concatenar.
    }

}
