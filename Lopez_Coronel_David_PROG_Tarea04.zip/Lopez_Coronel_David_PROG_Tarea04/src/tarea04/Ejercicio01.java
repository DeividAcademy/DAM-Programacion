package tarea04;

import java.util.Scanner;

/**
 * @author David López Coronel.
 */

public class Ejercicio01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String cadena1 = "";
        String cadena2 = "";

        // Variables de salida
        StringBuilder strb = new StringBuilder("");
        
        // Variables auxiliares
        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("MEZCLA DE CADENAS");
        System.out.println("-----------------");

        // Leer primera cadena controlando el tamaño que sea de al menos 5 caracteres
        do {
            System.out.print("Introduce una cadena de 5 o más caracteres: ");
            cadena1 = teclado.nextLine();
            if (cadena1.length() < 5) {
                System.out.println("Cadena no válida.");
            }

        } while (cadena1.length() < 5);

        // Leer segunda cadena controlando el tamaño que sea de al menos 5 caracteres
        do {
            System.out.print("Introduce otra cadena de 5 o más caracteres: ");
            cadena2 = teclado.nextLine();
            if (cadena2.length() < 5) {
                System.out.println("Cadena no válida.");
            }

        } while (cadena2.length() < 5);

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
                
        for (int contador = 0; contador < cadena1.length() || contador < cadena2.length(); contador++) {
            if (contador < cadena1.length()) {
                strb.append(cadena1.charAt(contador));
            }
            
            if (contador < cadena2.length()) {//con este if, comprabamos que siempre sea menor que la longitud de la cadena y asi evitamos la excepcion.
                strb.append(cadena2.charAt(contador));
            }
            
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: CADENAS MEZCLADAS");
        System.out.println("----------------------------");
        
        System.out.printf("El resultado de mezclar \"%s\" con \"%s\" es \"%s\"\n", cadena1, cadena2, strb);

    }

}
