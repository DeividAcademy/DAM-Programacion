package tarea2;

import java.util.Scanner;

/**
 * Ejercicio 3: número de días del mes. Estamos interesados en saber cuántos
 * días puede tener un mes del calendario y nos han pedido que lo hagamos
 * utilizando la sentencia switch y sin hacer uso de la sentencia if.
 *
 * Implementar un programa en Java que solicite al usuario un mes (número entero
 * entre 1 y 12) de manera que:
 *
 * si el valor del mes es correcto, el programa procederá a obtener cuántos días
 * tiene ese mes y lo mostrará por pantalla. Se supone un año no bisiesto, es
 * decir, que febrero tendrá 28 días; si el valor del mes no es correcto (número
 * fuera del rango indicado 1-12) se mostrará el valor 0.
 *
 * Ten en cuenta que:
 * <ul>
 * <li>se deberá utilizar la estructura "switch" obligatoriamente;</li>
 * <li>se valorará que se minimice el número de líneas. Procura que cuando haya
 * varias circunstancias (cláusulas case) en las que se deba hacer la misma
 * acción, estén todas agrupadas y se lleve a cabo esa acción una sola vez;</li>
 * <li>la comprobación de que el número no está en el rango debe hacerse también
 * dentro de la estructura switch. Para eso dispones de la cláusula
 * default;</li>
 * <li>no puedes usar ningún método, ni la API de Java ni propio, en ninguna
 * parte del código. Tampoco se puede usar ninguna clase adicional, ni propia ni
 * del API de Java, para resolver el ejercicio;</li>
 * <li>no pueden utilizarse estructuras "if/else" o "if/elseif/else". ni el
 * operador condicional (?). El objetivo de este ejercicio es que practiques con
 * el uso de la estructura "switch".</li>
 * </ul>
 *
 * @author David López Coronel.
 */
public class Ejercicio03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes        
        // Variables de entrada
        int mes;

        // Variables de salida
        int numeroDias = 0;

        // Variables auxiliares        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("NÚMERO DE DÍAS DEL MES");
        System.out.println("----------------------");

        System.out.println("Introduzca un mes, (del 1 al 12); ");
        mes = teclado.nextInt();

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        boolean mesValido = (mes >= 1) && (mes <= 12);

        switch (mes) {
            case 2:
                numeroDias = 28;
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                numeroDias = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                numeroDias = 30;
                break;
            default:
                mesValido = false;
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        if (mesValido == false) {
            System.out.println("Número mes, fuera del rango indicado (1-12); \ndías para ese mes 0");
        } else {
            System.out.println("El número de días para ese mes, es: " + numeroDias);
        }
    }
}
