/**
 * @author David López Coronel
 */

/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;

/*
Ejercicio 2: cálculos aritméticos.

Escribe un programa en Java que solicite dos números reales y lleve a cabo los siguientes cálculos:

    el doble del primer número,
    la mitad del segundo número,
    el cuadrado de la suma de ambos números,
    La décima parte de la suma los cuadrados de ambos números.

Para ello tendrás que utilizar operadores aritméticos tales como la suma, el producto o la división. 
Además, es posible que en algunos casos necesites hacer uso de los paréntesis.
*/

public class Ejercicio2 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes

        // Variables de entrada
        float primerNumero, segundoNumero;
                
        // Variables de salida

        // Variables auxiliares

        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
                
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
       
        System.out.println("Ejercicio 2.\nCÁLCULOS ARITMÉTICOS");
        System.out.println("----------------------");
        
        System.out.println("Introduzca dos números reales: ");
        System.out.print( "Primer número: ");
        primerNumero = teclado.nextFloat();
        System.out.print( "Segundo número: ");
        segundoNumero = teclado.nextFloat();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
      
                        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
                
        System.out.println ("Doble del primer número: " + primerNumero * 2 );
        System.out.println ("Mitad del segundo número: " + segundoNumero / 2);
        System.out.println ("Cuadrado de la suma de ambos números: " + (primerNumero + segundoNumero) * (primerNumero + segundoNumero) );
        System.out.println ("Décima parte de la suma de los cuadrados de ambos números: " + ((primerNumero * primerNumero) + (segundoNumero * segundoNumero)) / 10 );
        System.out.println ();
	System.out.println ("Fin del programa. Bye!");        
        
    }
    
}